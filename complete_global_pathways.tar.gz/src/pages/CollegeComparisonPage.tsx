import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { 
  Search, 
  Plus, 
  X, 
  DollarSign, 
  Users, 
  GraduationCap, 
  MapPin, 
  Star,
  TrendingUp,
  Award,
  ExternalLink,
  BookOpen,
  Home,
  Calculator,
  Target,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';

interface College {
  id: string;
  name: string;
  location: string;
  state: string;
  college_type: string;
  admission_rate: number;
  tuition_in_state: number;
  tuition_out_state: number;
  total_cost: number;
  undergraduate_enrollment: number;
  acceptance_rate_international: number;
  need_blind_domestic: boolean;
  need_blind_international: boolean;
  meets_full_need: boolean;
  no_loan_policy: boolean;
  average_aid_amount: number;
  application_platform: string;
  sat_range_25th: number;
  sat_range_75th: number;
  act_range_25th: number;
  act_range_75th: number;
  gpa_average: number;
  campus_setting: string;
  website_url: string;
  test_optional: boolean;
}

export const CollegeComparisonPage: React.FC = () => {
  const [colleges, setColleges] = useState<College[]>([]);
  const [selectedColleges, setSelectedColleges] = useState<College[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredColleges, setFilteredColleges] = useState<College[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadColleges();
  }, []);

  useEffect(() => {
    if (searchTerm) {
      const filtered = colleges.filter(college =>
        college.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        college.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        college.state.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredColleges(filtered.slice(0, 10));
    } else {
      setFilteredColleges([]);
    }
  }, [searchTerm, colleges]);

  const loadColleges = async () => {
    try {
      const { data, error } = await supabase
        .from('colleges_database_2025_10_06_01_15')
        .select('*')
        .order('name');

      if (data && !error) {
        setColleges(data);
      }
    } catch (error) {
      console.error('Error loading colleges:', error);
    } finally {
      setLoading(false);
    }
  };

  const addCollegeToComparison = (college: College) => {
    if (selectedColleges.length < 4 && !selectedColleges.find(c => c.id === college.id)) {
      setSelectedColleges([...selectedColleges, college]);
      setSearchTerm('');
      setFilteredColleges([]);
    }
  };

  const removeCollegeFromComparison = (collegeId: string) => {
    setSelectedColleges(selectedColleges.filter(c => c.id !== collegeId));
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getCollegeTypeColor = (type: string) => {
    switch (type) {
      case 'ivy_league': return 'bg-purple-100 text-purple-800';
      case 't20': return 'bg-blue-100 text-blue-800';
      case 'state_school': return 'bg-green-100 text-green-800';
      case 'liberal_arts': return 'bg-orange-100 text-orange-800';
      case 'technical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAdmissionDifficulty = (rate: number) => {
    if (rate <= 10) return { label: 'Most Competitive', color: 'text-red-600', icon: AlertCircle };
    if (rate <= 25) return { label: 'Highly Competitive', color: 'text-orange-600', icon: AlertCircle };
    if (rate <= 50) return { label: 'Competitive', color: 'text-yellow-600', icon: Info };
    if (rate <= 75) return { label: 'Moderately Competitive', color: 'text-blue-600', icon: Info };
    return { label: 'Less Competitive', color: 'text-green-600', icon: CheckCircle };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading colleges...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">College Comparison Tool</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Compare up to 4 colleges side-by-side to make informed decisions about your education
          </p>
        </div>

        {/* College Search */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Search className="h-5 w-5 mr-2" />
              Add Colleges to Compare
            </CardTitle>
            <CardDescription>
              Search and select up to 4 colleges to compare ({selectedColleges.length}/4 selected)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <Input
                type="text"
                placeholder="Search colleges by name, location, or state..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
              
              {filteredColleges.length > 0 && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-y-auto">
                  {filteredColleges.map((college) => (
                    <div
                      key={college.id}
                      className="p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                      onClick={() => addCollegeToComparison(college)}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{college.name}</h4>
                          <p className="text-sm text-gray-600">{college.location}</p>
                        </div>
                        <Badge className={getCollegeTypeColor(college.college_type)}>
                          {college.college_type.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Selected Colleges Preview */}
            {selectedColleges.length > 0 && (
              <div className="mt-4">
                <h4 className="font-medium text-gray-900 mb-2">Selected Colleges:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedColleges.map((college) => (
                    <Badge key={college.id} variant="outline" className="flex items-center gap-1">
                      {college.name}
                      <button
                        onClick={() => removeCollegeFromComparison(college.id)}
                        className="ml-1 hover:text-red-600"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Comparison Table */}
        {selectedColleges.length > 0 && (
          <div className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-4 font-medium text-gray-900">Attribute</th>
                        {selectedColleges.map((college) => (
                          <th key={college.id} className="text-left py-2 px-4 font-medium text-gray-900 min-w-48">
                            <div>
                              <div className="font-bold">{college.name}</div>
                              <div className="text-sm font-normal text-gray-600">{college.location}</div>
                            </div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">College Type</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            <Badge className={getCollegeTypeColor(college.college_type)}>
                              {college.college_type.replace('_', ' ').toUpperCase()}
                            </Badge>
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Campus Setting</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4 capitalize">
                            {college.campus_setting || 'Not specified'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Undergraduate Enrollment</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.undergraduate_enrollment?.toLocaleString() || 'Not available'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Website</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.website_url ? (
                              <a
                                href={college.website_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:text-blue-800 flex items-center"
                              >
                                Visit Website
                                <ExternalLink className="h-4 w-4 ml-1" />
                              </a>
                            ) : (
                              'Not available'
                            )}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Admissions */}
            <Card>
              <CardHeader>
                <CardTitle>Admissions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-4 font-medium text-gray-900">Attribute</th>
                        {selectedColleges.map((college) => (
                          <th key={college.id} className="text-left py-2 px-4 font-medium text-gray-900">
                            {college.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Acceptance Rate</td>
                        {selectedColleges.map((college) => {
                          const difficulty = getAdmissionDifficulty(college.admission_rate || 0);
                          const DifficultyIcon = difficulty.icon;
                          return (
                            <td key={college.id} className="py-3 px-4">
                              <div className="flex items-center">
                                <span className="font-semibold">{college.admission_rate}%</span>
                                <DifficultyIcon className={`h-4 w-4 ml-2 ${difficulty.color}`} />
                              </div>
                              <div className={`text-xs ${difficulty.color}`}>
                                {difficulty.label}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">SAT Range (25th-75th)</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.sat_range_25th && college.sat_range_75th
                              ? `${college.sat_range_25th} - ${college.sat_range_75th}`
                              : 'Not available'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">ACT Range (25th-75th)</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.act_range_25th && college.act_range_75th
                              ? `${college.act_range_25th} - ${college.act_range_75th}`
                              : 'Not available'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Average GPA</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.gpa_average || 'Not available'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Test Optional</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.test_optional ? (
                              <Badge className="bg-green-100 text-green-800">Yes</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-800">No</Badge>
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Application Platform</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.application_platform || 'Not specified'}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Costs and Financial Aid */}
            <Card>
              <CardHeader>
                <CardTitle>Costs and Financial Aid</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-2 px-4 font-medium text-gray-900">Attribute</th>
                        {selectedColleges.map((college) => (
                          <th key={college.id} className="text-left py-2 px-4 font-medium text-gray-900">
                            {college.name}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">In-State Tuition</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4 font-semibold">
                            {formatCurrency(college.tuition_in_state || 0)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Out-of-State Tuition</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4 font-semibold">
                            {formatCurrency(college.tuition_out_state || 0)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Total Cost of Attendance</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4 font-semibold text-red-600">
                            {formatCurrency(college.total_cost || 0)}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Average Aid Amount</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4 font-semibold text-green-600">
                            {college.average_aid_amount ? formatCurrency(college.average_aid_amount) : 'Not available'}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Need-Blind Admissions (Domestic)</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.need_blind_domestic ? (
                              <Badge className="bg-green-100 text-green-800">Yes</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-800">No</Badge>
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">Meets Full Need</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.meets_full_need ? (
                              <Badge className="bg-green-100 text-green-800">Yes</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-800">No</Badge>
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr className="border-b">
                        <td className="py-3 px-4 font-medium">No-Loan Policy</td>
                        {selectedColleges.map((college) => (
                          <td key={college.id} className="py-3 px-4">
                            {college.no_loan_policy ? (
                              <Badge className="bg-green-100 text-green-800">Yes</Badge>
                            ) : (
                              <Badge className="bg-red-100 text-red-800">No</Badge>
                            )}
                          </td>
                        ))}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-center space-x-4">
              <Button onClick={() => setSelectedColleges([])} variant="outline">
                Clear All Colleges
              </Button>
              <Button onClick={() => window.print()}>
                Print Comparison
              </Button>
            </div>
          </div>
        )}

        {selectedColleges.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <GraduationCap className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Colleges Selected</h3>
              <p className="text-gray-600 mb-4">
                Search and select colleges above to start comparing them side-by-side.
              </p>
              <p className="text-sm text-gray-500">
                You can compare up to 4 colleges at once.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};