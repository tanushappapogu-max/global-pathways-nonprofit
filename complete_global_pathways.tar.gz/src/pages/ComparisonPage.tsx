import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  BarChart3, 
  Plus, 
  X, 
  DollarSign, 
  Users, 
  MapPin, 
  GraduationCap,
  CheckCircle,
  XCircle,
  Calculator
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface College {
  name: string;
  location: string;
  type: string;
  admissionRate?: string;
  tuition?: string;
  undergrads: string;
  financialAid: {
    needBlind: boolean;
    meetsFullNeed: boolean;
    noLoans: boolean;
    internationalAid: boolean;
  };
}

interface FinancialAidCalculation {
  familyIncome: number;
  assets: number;
  expectedContribution: number;
  needBasedAid: number;
}

const sampleColleges: College[] = [
  {
    name: "Harvard University",
    location: "Cambridge, MA",
    type: "Ivy League",
    admissionRate: "3.4%",
    tuition: "$54,269",
    undergrads: "7,000",
    financialAid: {
      needBlind: true,
      meetsFullNeed: true,
      noLoans: true,
      internationalAid: true
    }
  },
  {
    name: "Stanford University",
    location: "Stanford, CA",
    type: "T20",
    admissionRate: "3.9%",
    tuition: "$56,169",
    undergrads: "7,000",
    financialAid: {
      needBlind: true,
      meetsFullNeed: true,
      noLoans: true,
      internationalAid: false
    }
  },
  {
    name: "MIT",
    location: "Cambridge, MA",
    type: "T20",
    admissionRate: "6.7%",
    tuition: "$53,790",
    undergrads: "4,500",
    financialAid: {
      needBlind: true,
      meetsFullNeed: true,
      noLoans: true,
      internationalAid: true
    }
  }
];

export const ComparisonPage: React.FC = () => {
  const { user } = useAuth();
  const [selectedColleges, setSelectedColleges] = useState<College[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [savedComparisons, setSavedComparisons] = useState<any[]>([]);
  const [comparisonName, setComparisonName] = useState('');
  
  // Financial Aid Calculator State
  const [familyIncome, setFamilyIncome] = useState<number>(0);
  const [familyAssets, setFamilyAssets] = useState<number>(0);
  const [studentIncome, setStudentIncome] = useState<number>(0);
  const [studentAssets, setStudentAssets] = useState<number>(0);
  const [householdSize, setHouseholdSize] = useState<number>(4);
  const [studentsInCollege, setStudentsInCollege] = useState<number>(1);

  useEffect(() => {
    if (user) {
      fetchSavedComparisons();
    }
  }, [user]);

  const fetchSavedComparisons = async () => {
    try {
      const { data } = await supabase
        .from('college_comparisons_2025_10_01_13_00')
        .select('*')
        .eq('user_id', user?.id);
      
      if (data) {
        setSavedComparisons(data);
      }
    } catch (error) {
      console.error('Error fetching saved comparisons:', error);
    }
  };

  const addCollege = (college: College) => {
    if (selectedColleges.length >= 4) {
      toast({
        title: "Limit Reached",
        description: "You can compare up to 4 colleges at a time",
        variant: "destructive",
      });
      return;
    }

    if (selectedColleges.find(c => c.name === college.name)) {
      toast({
        title: "Already Added",
        description: "This college is already in your comparison",
        variant: "destructive",
      });
      return;
    }

    setSelectedColleges([...selectedColleges, college]);
  };

  const removeCollege = (collegeName: string) => {
    setSelectedColleges(selectedColleges.filter(c => c.name !== collegeName));
  };

  const saveComparison = async () => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please log in to save comparisons",
        variant: "destructive",
      });
      return;
    }

    if (selectedColleges.length === 0) {
      toast({
        title: "No Colleges Selected",
        description: "Please select colleges to compare before saving",
        variant: "destructive",
      });
      return;
    }

    if (!comparisonName.trim()) {
      toast({
        title: "Name Required",
        description: "Please enter a name for this comparison",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('college_comparisons_2025_10_01_13_00')
        .insert({
          user_id: user.id,
          comparison_name: comparisonName,
          colleges: selectedColleges
        });

      if (error) throw error;

      toast({
        title: "Comparison Saved",
        description: "Your college comparison has been saved",
      });

      setComparisonName('');
      fetchSavedComparisons();
    } catch (error) {
      console.error('Error saving comparison:', error);
      toast({
        title: "Error",
        description: "Failed to save comparison",
        variant: "destructive",
      });
    }
  };

  const calculateEFC = (): number => {
    // Simplified EFC calculation (actual FAFSA calculation is much more complex)
    const parentContribution = Math.max(0, (familyIncome - 25000) * 0.22 + familyAssets * 0.12);
    const studentContribution = studentIncome * 0.5 + studentAssets * 0.2;
    const adjustedContribution = (parentContribution + studentContribution) / studentsInCollege;
    
    return Math.round(adjustedContribution);
  };

  const calculateNeedBasedAid = (tuitionString: string): number => {
    const tuition = parseInt(tuitionString.replace(/[^0-9]/g, '')) || 0;
    const totalCost = tuition + 15000; // Adding estimated room, board, and other expenses
    const efc = calculateEFC();
    
    return Math.max(0, totalCost - efc);
  };

  const filteredColleges = sampleColleges.filter(college =>
    college.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    college.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">College Comparison Tool</h1>
          <p className="text-gray-600">
            Compare colleges side by side and calculate estimated financial aid
          </p>
        </div>

        <Tabs defaultValue="comparison" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="comparison">College Comparison</TabsTrigger>
            <TabsTrigger value="calculator">Financial Aid Calculator</TabsTrigger>
          </TabsList>

          <TabsContent value="comparison" className="mt-8">
            <div className="grid lg:grid-cols-4 gap-8">
              {/* College Selection */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Plus className="h-5 w-5 mr-2" />
                      Add Colleges
                    </CardTitle>
                    <CardDescription>
                      Search and add colleges to compare (max 4)
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <Input
                        placeholder="Search colleges..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                      
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {filteredColleges.map((college) => (
                          <div
                            key={college.name}
                            className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer"
                            onClick={() => addCollege(college)}
                          >
                            <h4 className="font-medium text-sm">{college.name}</h4>
                            <p className="text-xs text-gray-600">{college.location}</p>
                            <Badge variant="outline" className="text-xs mt-1">
                              {college.type}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Save Comparison */}
                {selectedColleges.length > 0 && user && (
                  <Card className="mt-6">
                    <CardHeader>
                      <CardTitle className="text-lg">Save Comparison</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <Input
                          placeholder="Comparison name..."
                          value={comparisonName}
                          onChange={(e) => setComparisonName(e.target.value)}
                        />
                        <Button onClick={saveComparison} className="w-full">
                          Save Comparison
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>

              {/* Comparison Table */}
              <div className="lg:col-span-3">
                {selectedColleges.length > 0 ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center">
                        <BarChart3 className="h-5 w-5 mr-2" />
                        College Comparison
                      </CardTitle>
                      <CardDescription>
                        Compare {selectedColleges.length} selected colleges
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-3 px-4 font-medium">Criteria</th>
                              {selectedColleges.map((college) => (
                                <th key={college.name} className="text-left py-3 px-4 min-w-48">
                                  <div className="flex items-center justify-between">
                                    <div>
                                      <div className="font-medium">{college.name}</div>
                                      <div className="text-sm text-gray-600">{college.location}</div>
                                    </div>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeCollege(college.name)}
                                      className="text-red-600 hover:text-red-700"
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </div>
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Type</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  <Badge variant="outline">{college.type}</Badge>
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Admission Rate</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.admissionRate || 'N/A'}
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Tuition</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.tuition || 'N/A'}
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Undergraduates</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.undergrads}
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Need-Blind</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.financialAid.needBlind ? (
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-600" />
                                  )}
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">Meets Full Need</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.financialAid.meetsFullNeed ? (
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-600" />
                                  )}
                                </td>
                              ))}
                            </tr>
                            
                            <tr className="border-b">
                              <td className="py-3 px-4 font-medium">No Loans</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.financialAid.noLoans ? (
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-600" />
                                  )}
                                </td>
                              ))}
                            </tr>
                            
                            <tr>
                              <td className="py-3 px-4 font-medium">International Aid</td>
                              {selectedColleges.map((college) => (
                                <td key={college.name} className="py-3 px-4">
                                  {college.financialAid.internationalAid ? (
                                    <CheckCircle className="h-5 w-5 text-green-600" />
                                  ) : (
                                    <XCircle className="h-5 w-5 text-red-600" />
                                  )}
                                </td>
                              ))}
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="pt-12 pb-12 text-center">
                      <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-900 mb-2">No Colleges Selected</h3>
                      <p className="text-gray-600">
                        Select colleges from the left panel to start comparing
                      </p>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="calculator" className="mt-8">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Calculator Input */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calculator className="h-5 w-5 mr-2" />
                    Financial Aid Calculator
                  </CardTitle>
                  <CardDescription>
                    Estimate your Expected Family Contribution (EFC) and potential need-based aid
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h4 className="font-medium mb-4">Family Information</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="familyIncome">Family Income ($)</Label>
                          <Input
                            id="familyIncome"
                            type="number"
                            value={familyIncome || ''}
                            onChange={(e) => setFamilyIncome(Number(e.target.value))}
                            placeholder="75000"
                          />
                        </div>
                        <div>
                          <Label htmlFor="familyAssets">Family Assets ($)</Label>
                          <Input
                            id="familyAssets"
                            type="number"
                            value={familyAssets || ''}
                            onChange={(e) => setFamilyAssets(Number(e.target.value))}
                            placeholder="50000"
                          />
                        </div>
                        <div>
                          <Label htmlFor="householdSize">Household Size</Label>
                          <Input
                            id="householdSize"
                            type="number"
                            value={householdSize || ''}
                            onChange={(e) => setHouseholdSize(Number(e.target.value))}
                            placeholder="4"
                          />
                        </div>
                        <div>
                          <Label htmlFor="studentsInCollege">Students in College</Label>
                          <Input
                            id="studentsInCollege"
                            type="number"
                            value={studentsInCollege || ''}
                            onChange={(e) => setStudentsInCollege(Number(e.target.value))}
                            placeholder="1"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-4">Student Information</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="studentIncome">Student Income ($)</Label>
                          <Input
                            id="studentIncome"
                            type="number"
                            value={studentIncome || ''}
                            onChange={(e) => setStudentIncome(Number(e.target.value))}
                            placeholder="3000"
                          />
                        </div>
                        <div>
                          <Label htmlFor="studentAssets">Student Assets ($)</Label>
                          <Input
                            id="studentAssets"
                            type="number"
                            value={studentAssets || ''}
                            onChange={(e) => setStudentAssets(Number(e.target.value))}
                            placeholder="5000"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Calculator Results */}
              <Card>
                <CardHeader>
                  <CardTitle>Estimated Financial Aid</CardTitle>
                  <CardDescription>
                    Based on your family's financial information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-blue-900 mb-2">Expected Family Contribution (EFC)</h4>
                      <p className="text-2xl font-bold text-blue-700">
                        ${calculateEFC().toLocaleString()}
                      </p>
                      <p className="text-sm text-blue-600 mt-1">
                        Amount your family is expected to contribute annually
                      </p>
                    </div>

                    {selectedColleges.length > 0 && (
                      <div>
                        <h4 className="font-semibold mb-4">Estimated Need-Based Aid by College</h4>
                        <div className="space-y-3">
                          {selectedColleges.map((college) => {
                            const needBasedAid = calculateNeedBasedAid(college.tuition || '0');
                            return (
                              <div key={college.name} className="p-3 border border-gray-200 rounded-lg">
                                <div className="flex justify-between items-center">
                                  <span className="font-medium">{college.name}</span>
                                  <span className="text-lg font-semibold text-green-600">
                                    ${needBasedAid.toLocaleString()}
                                  </span>
                                </div>
                                <p className="text-sm text-gray-600">
                                  Estimated annual need-based aid
                                </p>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h5 className="font-medium text-yellow-800 mb-2">Important Note</h5>
                      <p className="text-sm text-yellow-700">
                        This is a simplified estimate. Actual financial aid calculations involve many more factors. 
                        Always use the official Net Price Calculator on each college's website for more accurate estimates.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};