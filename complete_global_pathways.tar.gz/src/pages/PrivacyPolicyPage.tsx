import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  FileText, 
  Lock, 
  Eye, 
  UserCheck,
  AlertTriangle,
  CheckCircle,
  Mail,
  Calendar
} from 'lucide-react';

export const PrivacyPolicyPage: React.FC = () => {
  const [lastUpdated] = useState('October 6, 2024');

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Privacy Policy & Terms of Service</h1>
          <p className="text-lg text-gray-600">
            Your privacy and security are our top priorities. Learn how we protect your information.
          </p>
          <div className="flex items-center justify-center mt-4 text-sm text-gray-500">
            <Calendar className="h-4 w-4 mr-2" />
            Last updated: {lastUpdated}
          </div>
        </div>

        <Tabs defaultValue="privacy" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="privacy" className="flex items-center">
              <Shield className="h-4 w-4 mr-2" />
              Privacy Policy
            </TabsTrigger>
            <TabsTrigger value="terms" className="flex items-center">
              <FileText className="h-4 w-4 mr-2" />
              Terms of Service
            </TabsTrigger>
          </TabsList>

          {/* Privacy Policy Tab */}
          <TabsContent value="privacy" className="space-y-6">
            {/* Key Principles */}
            <Card className="border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center text-green-800">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Our Privacy Commitment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-start">
                    <Lock className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>No SSN Collection:</strong> We never collect Social Security Numbers</span>
                  </div>
                  <div className="flex items-start">
                    <Eye className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Educational Use Only:</strong> Data used solely for college guidance</span>
                  </div>
                  <div className="flex items-start">
                    <UserCheck className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Your Control:</strong> Delete your account and data anytime</span>
                  </div>
                  <div className="flex items-start">
                    <Shield className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Secure Storage:</strong> Bank-level encryption for all data</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Information We Collect */}
            <Card>
              <CardHeader>
                <CardTitle>Information We Collect</CardTitle>
                <CardDescription>
                  We collect only the information necessary to provide our college guidance services
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Account Information</h4>
                  <ul className="space-y-1 text-sm text-gray-600 ml-4">
                    <li>• Name and email address (required for account creation)</li>
                    <li>• Grade level and graduation year</li>
                    <li>• Country of residence</li>
                    <li>• Preferred language for communications</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Educational Information</h4>
                  <ul className="space-y-1 text-sm text-gray-600 ml-4">
                    <li>• Academic interests and intended major</li>
                    <li>• College preferences and saved lists</li>
                    <li>• FAFSA completion progress (not actual FAFSA data)</li>
                    <li>• Scholarship applications and deadlines</li>
                  </ul>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Usage Information</h4>
                  <ul className="space-y-1 text-sm text-gray-600 ml-4">
                    <li>• Pages visited and features used</li>
                    <li>• Time spent on different sections</li>
                    <li>• Device type and browser information</li>
                    <li>• IP address (for security purposes only)</li>
                  </ul>
                </div>

                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-red-600 mr-2 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-red-800 mb-1">What We DON'T Collect</h4>
                      <ul className="text-sm text-red-700 space-y-1">
                        <li>• Social Security Numbers</li>
                        <li>• Bank account or financial information</li>
                        <li>• Actual FAFSA form data</li>
                        <li>• Parent tax information</li>
                        <li>• Immigration status details</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* How We Use Information */}
            <Card>
              <CardHeader>
                <CardTitle>How We Use Your Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-gray-600">
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Personalized Guidance:</strong> Customize college and scholarship recommendations</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Progress Tracking:</strong> Help you stay on track with deadlines and requirements</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Communication:</strong> Send important reminders and updates</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Service Improvement:</strong> Analyze usage patterns to enhance our platform</span>
                  </div>
                  <div className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-green-600 mr-2 mt-0.5" />
                    <span><strong>Support:</strong> Provide technical assistance and answer questions</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Data Sharing */}
            <Card>
              <CardHeader>
                <CardTitle>Data Sharing and Disclosure</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900 mb-2">We Share Information With:</h4>
                    <ul className="space-y-1 text-sm text-blue-800">
                      <li>• Your school counselors (only if you opt-in)</li>
                      <li>• Partner organizations (anonymized data only)</li>
                      <li>• Service providers (hosting, analytics) under strict agreements</li>
                    </ul>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-red-900 mb-2">We Never Share:</h4>
                    <ul className="space-y-1 text-sm text-red-800">
                      <li>• Personal information with colleges without your consent</li>
                      <li>• Data with marketing companies or advertisers</li>
                      <li>• Information for commercial purposes</li>
                      <li>• Any data that could identify you personally</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Your Rights */}
            <Card>
              <CardHeader>
                <CardTitle>Your Rights and Controls</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Access & Control</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• View all your data anytime</li>
                      <li>• Update or correct information</li>
                      <li>• Download your data</li>
                      <li>• Delete your account</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Communication Preferences</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Opt out of emails anytime</li>
                      <li>• Choose notification frequency</li>
                      <li>• Select preferred language</li>
                      <li>• Control counselor access</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* International Users */}
            <Card>
              <CardHeader>
                <CardTitle>International Users</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-sm text-gray-600">
                  <p>
                    <strong>GDPR Compliance:</strong> For users in the European Union, we comply with the General Data Protection Regulation (GDPR).
                  </p>
                  <p>
                    <strong>Data Transfers:</strong> Your data may be processed in the United States, where our servers are located. We ensure appropriate safeguards are in place.
                  </p>
                  <p>
                    <strong>Legal Basis:</strong> We process your data based on your consent and our legitimate interest in providing educational services.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Terms of Service Tab */}
          <TabsContent value="terms" className="space-y-6">
            {/* Acceptance */}
            <Card>
              <CardHeader>
                <CardTitle>Acceptance of Terms</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  By accessing and using Global Pathways, you accept and agree to be bound by the terms and provision of this agreement. 
                  If you do not agree to abide by the above, please do not use this service.
                </p>
              </CardContent>
            </Card>

            {/* Service Description */}
            <Card>
              <CardHeader>
                <CardTitle>Service Description</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 text-gray-600">
                  <p>
                    Global Pathways is a free educational platform that provides:
                  </p>
                  <ul className="space-y-1 ml-4">
                    <li>• Step-by-step FAFSA guidance</li>
                    <li>• Scholarship search and matching</li>
                    <li>• College cost calculators</li>
                    <li>• Application timeline management</li>
                    <li>• Educational resources and blog content</li>
                    <li>• Counselor portal for educators</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* User Responsibilities */}
            <Card>
              <CardHeader>
                <CardTitle>User Responsibilities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">You agree to:</h4>
                    <ul className="space-y-1 text-sm text-gray-600 ml-4">
                      <li>• Provide accurate and truthful information</li>
                      <li>• Use the service for educational purposes only</li>
                      <li>• Respect other users and maintain appropriate conduct</li>
                      <li>• Not attempt to hack, disrupt, or misuse the platform</li>
                      <li>• Keep your account credentials secure</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">You agree NOT to:</h4>
                    <ul className="space-y-1 text-sm text-gray-600 ml-4">
                      <li>• Share false or misleading information</li>
                      <li>• Use the platform for commercial purposes</li>
                      <li>• Attempt to access other users' accounts</li>
                      <li>• Upload malicious content or viruses</li>
                      <li>• Violate any applicable laws or regulations</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Disclaimers */}
            <Card>
              <CardHeader>
                <CardTitle>Important Disclaimers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-yellow-800 mb-1">Educational Guidance Only</h4>
                        <p className="text-sm text-yellow-700">
                          Global Pathways provides educational information and guidance. We are not financial advisors, 
                          immigration lawyers, or official representatives of any college or government agency.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-blue-600 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-blue-800 mb-1">No Guarantees</h4>
                        <p className="text-sm text-blue-700">
                          We cannot guarantee college admission, scholarship awards, or financial aid approval. 
                          Success depends on many factors beyond our control.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                    <div className="flex items-start">
                      <AlertTriangle className="h-5 w-5 text-red-600 mr-2 mt-0.5" />
                      <div>
                        <h4 className="font-semibold text-red-800 mb-1">Verify Information</h4>
                        <p className="text-sm text-red-700">
                          Always verify important information with official sources. College requirements, 
                          deadlines, and policies can change without notice.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Limitation of Liability */}
            <Card>
              <CardHeader>
                <CardTitle>Limitation of Liability</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm">
                  Global Pathways and its team members shall not be liable for any direct, indirect, incidental, 
                  special, or consequential damages resulting from the use or inability to use our service, 
                  including but not limited to damages for loss of profits, use, data, or other intangibles.
                </p>
              </CardContent>
            </Card>

            {/* Modifications */}
            <Card>
              <CardHeader>
                <CardTitle>Modifications to Terms</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-sm">
                  We reserve the right to modify these terms at any time. Users will be notified of significant 
                  changes via email or platform notification. Continued use of the service after modifications 
                  constitutes acceptance of the new terms.
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Contact Information */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="pt-6 text-center">
            <Mail className="h-8 w-8 text-blue-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Questions About Privacy or Terms?</h3>
            <p className="text-gray-600 mb-4">
              We're here to help. Contact us with any questions about our privacy practices or terms of service.
            </p>
            <Button className="bg-blue-600 hover:bg-blue-700">
              Contact Us
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};