import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Rocket, 
  Target, 
  Globe, 
  Bot, 
  Users, 
  GraduationCap,
  MessageCircle,
  Smartphone,
  Award,
  TrendingUp,
  Calendar,
  CheckCircle,
  Clock,
  Lightbulb,
  Heart,
  Building
} from 'lucide-react';

interface RoadmapItem {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'in-progress' | 'planned';
  quarter: string;
  year: number;
  features: string[];
  impact: string;
  icon: React.ReactNode;
}

export const RoadmapPage: React.FC = () => {
  const roadmapItems: RoadmapItem[] = [
    {
      id: '1',
      title: 'Platform Foundation',
      description: 'Core platform with FAFSA guidance, college database, and user accounts',
      status: 'completed',
      quarter: 'Q3',
      year: 2024,
      features: [
        'User registration and authentication',
        'Comprehensive college database',
        'FAFSA step-by-step guide',
        'Basic scholarship search',
        'Multilingual support (5 languages)'
      ],
      impact: '1,000+ students helped in first month',
      icon: <CheckCircle className="h-6 w-6" />
    },
    {
      id: '2',
      title: 'Enhanced Features & Analytics',
      description: 'Advanced tools, counselor portal, and impact tracking',
      status: 'completed',
      quarter: 'Q4',
      year: 2024,
      features: [
        'College cost calculator',
        'Counselor portal with student tracking',
        'Success stories and testimonials',
        'Impact metrics dashboard',
        'Partnership program launch'
      ],
      impact: '5,000+ students reached, 50+ partner schools',
      icon: <CheckCircle className="h-6 w-6" />
    },
    {
      id: '3',
      title: 'AI-Powered Assistance',
      description: 'Intelligent chatbot and personalized recommendations',
      status: 'in-progress',
      quarter: 'Q1',
      year: 2025,
      features: [
        'AI chatbot for FAFSA questions',
        'Personalized scholarship matching',
        'Smart deadline reminders',
        'Automated progress tracking',
        'Intelligent college recommendations'
      ],
      impact: 'Expected: 50% reduction in completion time',
      icon: <Bot className="h-6 w-6" />
    },
    {
      id: '4',
      title: 'Mobile App & Notifications',
      description: 'Native mobile apps with push notifications and offline access',
      status: 'planned',
      quarter: 'Q2',
      year: 2025,
      features: [
        'iOS and Android native apps',
        'Push notifications for deadlines',
        'Offline access to guides',
        'Document photo capture',
        'Voice-to-text for forms'
      ],
      impact: 'Expected: 80% mobile user engagement',
      icon: <Smartphone className="h-6 w-6" />
    },
    {
      id: '5',
      title: 'Global Expansion',
      description: 'Support for students applying to universities worldwide',
      status: 'planned',
      quarter: 'Q3',
      year: 2025,
      features: [
        'UK university application guide',
        'Canadian college resources',
        'Australian university support',
        'European study abroad programs',
        'Additional language support (10+ languages)'
      ],
      impact: 'Expected: 25,000+ international students',
      icon: <Globe className="h-6 w-6" />
    },
    {
      id: '6',
      title: 'Mentorship Network',
      description: 'Connect students with college mentors and alumni',
      status: 'planned',
      quarter: 'Q4',
      year: 2025,
      features: [
        'Peer mentorship matching',
        'Alumni mentor network',
        'Virtual mentorship sessions',
        'Group study sessions',
        'Career guidance integration'
      ],
      impact: 'Expected: 1,000+ mentor-student pairs',
      icon: <Users className="h-6 w-6" />
    },
    {
      id: '7',
      title: 'Advanced Analytics & Insights',
      description: 'Predictive analytics and success probability modeling',
      status: 'planned',
      quarter: 'Q1',
      year: 2026,
      features: [
        'Admission probability calculator',
        'Financial aid prediction models',
        'Success outcome tracking',
        'Institutional analytics for schools',
        'Policy impact research'
      ],
      impact: 'Expected: 90% accuracy in predictions',
      icon: <TrendingUp className="h-6 w-6" />
    },
    {
      id: '8',
      title: 'Enterprise & Government Partnerships',
      description: 'Large-scale institutional adoption and policy integration',
      status: 'planned',
      quarter: 'Q2',
      year: 2026,
      features: [
        'State education department partnerships',
        'Federal agency collaboration',
        'Enterprise school district licenses',
        'Policy research and advocacy',
        'International education partnerships'
      ],
      impact: 'Expected: 1M+ students reached annually',
      icon: <Building className="h-6 w-6" />
    }
  ];

  const visionGoals = [
    {
      title: '100,000 Students Helped',
      description: 'Reach 100,000 students worldwide by 2026',
      progress: 2.8,
      icon: <GraduationCap className="h-8 w-8 text-blue-600" />
    },
    {
      title: '$100M in Aid Unlocked',
      description: 'Help students access $100 million in financial aid',
      progress: 2.1,
      icon: <Award className="h-8 w-8 text-green-600" />
    },
    {
      title: '1,000 Partner Schools',
      description: 'Partner with 1,000 high schools and organizations',
      progress: 5.0,
      icon: <Building className="h-8 w-8 text-purple-600" />
    },
    {
      title: '50 Countries Served',
      description: 'Expand support to students in 50+ countries',
      progress: 10.0,
      icon: <Globe className="h-8 w-8 text-orange-600" />
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in-progress': return 'bg-blue-100 text-blue-800';
      case 'planned': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'in-progress': return <Clock className="h-4 w-4" />;
      case 'planned': return <Calendar className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Vision & Roadmap</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Building the future of college access. See where we've been, where we are, 
            and where we're heading to democratize higher education worldwide.
          </p>
        </div>

        {/* Vision Statement */}
        <section className="mb-16">
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardContent className="pt-12 pb-12 text-center">
              <Rocket className="h-16 w-16 mx-auto mb-6" />
              <h2 className="text-3xl font-bold mb-4">Our Vision for 2030</h2>
              <p className="text-xl text-blue-100 max-w-4xl mx-auto leading-relaxed">
                To become the world's leading platform for college access, helping 1 million students 
                annually navigate higher education opportunities regardless of their background, 
                location, or economic circumstances.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Key Goals */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">2026 Goals</h2>
            <p className="text-lg text-gray-600">
              Ambitious targets that will transform college access globally
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {visionGoals.map((goal, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-8">
                  <div className="mb-4">
                    {goal.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {goal.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4">
                    {goal.description}
                  </p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(goal.progress, 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500">
                    {goal.progress}% complete
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Roadmap Timeline */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Development Roadmap</h2>
            <p className="text-lg text-gray-600">
              Our journey from idea to global impact
            </p>
          </div>

          <div className="space-y-8">
            {roadmapItems.map((item, index) => (
              <Card key={item.id} className={`hover:shadow-lg transition-shadow ${item.status === 'completed' ? 'border-green-200' : item.status === 'in-progress' ? 'border-blue-200' : ''}`}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className={`p-3 rounded-full ${item.status === 'completed' ? 'bg-green-100 text-green-600' : item.status === 'in-progress' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'}`}>
                        {item.icon}
                      </div>
                      <div className="flex-1">
                        <CardTitle className="text-xl mb-2">{item.title}</CardTitle>
                        <CardDescription className="text-base mb-3">
                          {item.description}
                        </CardDescription>
                        <div className="flex items-center space-x-4">
                          <Badge className={getStatusColor(item.status)}>
                            {getStatusIcon(item.status)}
                            <span className="ml-1 capitalize">{item.status.replace('-', ' ')}</span>
                          </Badge>
                          <Badge variant="outline">
                            {item.quarter} {item.year}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Key Features</h4>
                      <ul className="space-y-2">
                        {item.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-start text-sm text-gray-600">
                            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <h4 className="font-semibold text-gray-900 mb-3">Expected Impact</h4>
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <TrendingUp className="h-5 w-5 text-blue-600 mb-2" />
                        <p className="text-sm text-blue-900">{item.impact}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Innovation Areas */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Innovation Focus Areas</h2>
            <p className="text-lg text-gray-600">
              Technologies and approaches driving our development
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="pt-8">
                <Bot className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Artificial Intelligence</h3>
                <p className="text-sm text-gray-600 mb-4">
                  AI-powered chatbots, personalized recommendations, and predictive analytics 
                  to provide intelligent guidance at scale.
                </p>
                <Badge variant="outline">Machine Learning</Badge>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-8">
                <MessageCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Conversational Interfaces</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Natural language processing to make complex financial aid processes 
                  accessible through simple conversations.
                </p>
                <Badge variant="outline">NLP</Badge>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-8">
                <Globe className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Global Accessibility</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Advanced translation, cultural adaptation, and accessibility features 
                  to serve diverse global communities.
                </p>
                <Badge variant="outline">Internationalization</Badge>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Community & Partnerships */}
        <section className="mb-16">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-8 pb-8">
              <div className="text-center mb-8">
                <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Building Together</h2>
                <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                  Our success depends on collaboration with educators, students, and organizations worldwide
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <GraduationCap className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Student Ambassadors</h3>
                  <p className="text-sm text-gray-600">
                    Students who share their experiences and help improve our platform
                  </p>
                </div>

                <div className="text-center">
                  <Heart className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Volunteer Network</h3>
                  <p className="text-sm text-gray-600">
                    Counselors, translators, and developers contributing their expertise
                  </p>
                </div>

                <div className="text-center">
                  <Building className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-gray-900 mb-2">Institutional Partners</h3>
                  <p className="text-sm text-gray-600">
                    Schools, nonprofits, and organizations amplifying our impact
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Get Involved */}
        <section className="text-center bg-blue-600 text-white rounded-lg p-12">
          <Lightbulb className="h-16 w-16 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Shape the Future with Us</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Have ideas for features? Want to contribute? Join our community of changemakers 
            working to democratize college access worldwide.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-blue-600 hover:bg-blue-50">
              <MessageCircle className="h-4 w-4 mr-2" />
              Share Feedback
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Users className="h-4 w-4 mr-2" />
              Join Our Community
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Heart className="h-4 w-4 mr-2" />
              Volunteer
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
};