import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { 
  Search, 
  DollarSign, 
  Calendar, 
  ExternalLink, 
  Filter,
  GraduationCap,
  MapPin,
  Users,
  Star,
  AlertTriangle,
  RefreshCw
} from 'lucide-react';

// Import ReactBits animations
import { ShinyText } from '@/components/animations/ShinyText';
import { Magnetic } from '@/components/animations/Magnetic';

interface Scholarship {
  source: string;
  source_id?: string;
  name: string;
  amount?: string;
  eligibility?: string;
  deadline?: string;
  link?: string;
  region?: string;
  category?: string;
  raw_json?: any;
  last_checked?: string;
  last_updated?: string;
  expired?: boolean;
  link_broken?: boolean;
  needs_review?: boolean;
  created_at?: string;
}

export const ScholarshipPage: React.FC = () => {
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [filteredScholarships, setFilteredScholarships] = useState<Scholarship[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [minAmount, setMinAmount] = useState<number | undefined>();
  const [maxAmount, setMaxAmount] = useState<number | undefined>();
  const [selectedRegion, setSelectedRegion] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [showExpired, setShowExpired] = useState(false);

  const regions = [
    'National', 'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware',
    'Florida', 'Georgia', 'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky',
    'Louisiana', 'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi',
    'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey', 'New Mexico',
    'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania',
    'Rhode Island', 'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
    'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
  ];

  const categories = [
    'STEM', 'Arts', 'General', 'Leadership', 'FirstGen', 'International', 'LowIncome', 'Merit', 'Other'
  ];

  useEffect(() => {
    fetchScholarships();
    
    // Set up real-time subscription
    const channel = supabase
      .channel('scholarships-updates')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'scholarships' }, 
        (payload) => {
          console.log('Scholarship update received:', payload);
          fetchScholarships(); // Reload scholarships when changes occur
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    applyFilters();
  }, [scholarships, searchTerm, minAmount, maxAmount, selectedRegion, selectedCategory, showExpired]);

  const fetchScholarships = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('scholarships')
        .select('*')
        .eq('needs_review', false)
        .order('deadline', { ascending: true });

      if (error) {
        console.error('Error fetching scholarships:', error);
        return;
      }

      setScholarships(data || []);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...scholarships];

    // Search term filter
    if (searchTerm) {
      filtered = filtered.filter(scholarship =>
        scholarship.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        scholarship.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (scholarship.eligibility && scholarship.eligibility.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    // Amount filters - parse amount string for filtering
    if (minAmount !== undefined) {
      filtered = filtered.filter(scholarship => {
        if (!scholarship.amount) return false;
        const amountMatch = scholarship.amount.match(/\$?([\d,]+)/);
        if (amountMatch) {
          const amount = parseInt(amountMatch[1].replace(/,/g, ''));
          return amount >= minAmount;
        }
        return false;
      });
    }

    if (maxAmount !== undefined) {
      filtered = filtered.filter(scholarship => {
        if (!scholarship.amount) return false;
        const amountMatch = scholarship.amount.match(/\$?([\d,]+)/);
        if (amountMatch) {
          const amount = parseInt(amountMatch[1].replace(/,/g, ''));
          return amount <= maxAmount;
        }
        return false;
      });
    }

    // Region filter
    if (selectedRegion && selectedRegion !== 'none') {
      filtered = filtered.filter(scholarship =>
        !scholarship.region || 
        scholarship.region.toLowerCase() === 'national' ||
        scholarship.region.toLowerCase().includes(selectedRegion.toLowerCase())
      );
    }

    // Category filter
    if (selectedCategory && selectedCategory !== 'none') {
      filtered = filtered.filter(scholarship =>
        scholarship.category &&
        scholarship.category.toLowerCase().includes(selectedCategory.toLowerCase())
      );
    }

    // Expired filter
    if (!showExpired) {
      const today = new Date();
      filtered = filtered.filter(scholarship =>
        !scholarship.expired && 
        (!scholarship.deadline || new Date(scholarship.deadline) >= today)
      );
    }

    setFilteredScholarships(filtered);
  };

  const clearFilters = () => {
    setSearchTerm('');
    setMinAmount(undefined);
    setMaxAmount(undefined);
    setSelectedRegion('none');
    setSelectedCategory('none');
    setShowExpired(false);
  };

  const reportScholarship = async (scholarshipId: string) => {
    try {
      await supabase.from('reports').insert({
        scholarship_id: scholarshipId,
        issue: 'User reported wrong info or broken link',
        created_at: new Date().toISOString()
      });
      alert('Thank you for reporting this issue. We will review it shortly.');
    } catch (error) {
      console.error('Error reporting scholarship:', error);
      alert('Failed to submit report. Please try again.');
    }
  };

  const formatDeadline = (deadline?: string) => {
    if (!deadline) return 'No deadline specified';
    
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil < 0) return 'Deadline passed';
    if (daysUntil <= 30) return `${daysUntil} days left`;
    if (daysUntil <= 60) return `${daysUntil} days left`;
    return deadlineDate.toLocaleDateString();
  };

  const getDeadlineColor = (deadline?: string) => {
    if (!deadline) return 'text-gray-500';
    
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil < 0) return 'text-red-500';
    if (daysUntil <= 30) return 'text-red-500';
    if (daysUntil <= 60) return 'text-yellow-500';
    return 'text-green-500';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <RefreshCw className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-600">Loading scholarships...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <ShinyText 
            text="Scholarship Search" 
            className="text-4xl font-bold text-gray-900 mb-4"
          />
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover thousands of scholarships updated in real-time from trusted sources
          </p>
          <div className="mt-4 flex items-center justify-center space-x-4">
            <Magnetic strength={0.1}>
              <Badge className="bg-green-100 text-green-800">
                {filteredScholarships.length} Available
              </Badge>
            </Magnetic>
            <Magnetic strength={0.1}>
              <Badge className="bg-blue-100 text-blue-800">
                Real-time Updates
              </Badge>
            </Magnetic>
          </div>
        </div>
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Filter className="h-5 w-5 mr-2" />
              Search & Filter
            </CardTitle>
            <CardDescription>
              Find scholarships that match your criteria
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Search */}
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Search scholarships..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Amount Range */}
              <div className="space-y-2">
                <Label>Amount Range</Label>
                <div className="flex space-x-2">
                  <Input
                    type="number"
                    placeholder="Min $"
                    value={minAmount || ''}
                    onChange={(e) => setMinAmount(e.target.value ? parseInt(e.target.value) : undefined)}
                  />
                  <Input
                    type="number"
                    placeholder="Max $"
                    value={maxAmount || ''}
                    onChange={(e) => setMaxAmount(e.target.value ? parseInt(e.target.value) : undefined)}
                  />
                </div>
              </div>

              {/* Region */}
              <div className="space-y-2">
                <Label htmlFor="region">Region</Label>
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">All Regions</SelectItem>
                    {regions.map((region) => (
                      <SelectItem key={region} value={region}>
                        {region}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Category */}
              <div className="space-y-2">
                <Label htmlFor="category">Category</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">All Categories</SelectItem>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Show Expired */}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="expired"
                  checked={showExpired}
                  onCheckedChange={(checked) => setShowExpired(!!checked)}
                />
                <Label htmlFor="expired">Show expired scholarships</Label>
              </div>

              {/* Clear Filters */}
              <div className="flex items-end">
                <Button onClick={clearFilters} variant="outline" className="w-full">
                  Clear Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="space-y-6" data-testid="scholarship-list">
          {filteredScholarships.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Search className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Scholarships Found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your search criteria or clearing filters.
                </p>
                <Button onClick={clearFilters} variant="outline">
                  Clear All Filters
                </Button>
              </CardContent>
            </Card>
          ) : (
            filteredScholarships.map((scholarship) => (
              <Card key={scholarship.id} className="hover:shadow-lg transition-shadow" data-testid="scholarship-card">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h3 className="text-xl font-bold text-gray-900 mr-3">
                          {scholarship.name}
                        </h3>
                        {scholarship.link_broken && (
                          <Badge variant="destructive" className="flex items-center">
                            <AlertTriangle className="h-3 w-3 mr-1" />
                            Link Issue
                          </Badge>
                        )}
                      </div>
                      <p className="text-gray-600 mb-2">Source: {scholarship.source}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-1" />
                          {scholarship.amount || 'See provider'}
                        </span>
                        <span className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span className={getDeadlineColor(scholarship.deadline)}>
                            {formatDeadline(scholarship.deadline)}
                          </span>
                        </span>
                        {scholarship.region && (
                          <span className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {scholarship.region}
                          </span>
                        )}
                        {scholarship.category && (
                          <Badge variant="outline">
                            {scholarship.category}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => reportScholarship(scholarship.id)}
                        className="text-gray-400 hover:text-red-600"
                        data-testid="report-btn"
                      >
                        <AlertTriangle className="h-4 w-4" />
                      </Button>
                      {scholarship.link && !scholarship.link_broken && (
                        <Button asChild>
                          <a
                            href={scholarship.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center"
                          >
                            Apply Now
                            <ExternalLink className="h-4 w-4 ml-2" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>

                  {scholarship.eligibility && (
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-medium text-gray-900 mb-2">Eligibility Requirements</h4>
                      <p className="text-sm text-gray-600">{scholarship.eligibility}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};