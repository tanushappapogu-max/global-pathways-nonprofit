import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  GraduationCap, 
  Calendar, 
  BookOpen, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Plus,
  TrendingUp
} from 'lucide-react';
import { Link } from 'react-router-dom';

interface UserProfile {
  student_type?: string;
  citizenship_status?: string;
  graduation_year?: number;
}

interface SavedCollege {
  id: string;
  college_name: string;
  college_type: string;
  application_status: string;
  application_deadline?: string;
}

interface TimelineTask {
  id: string;
  task_title: string;
  due_date?: string;
  completed: boolean;
  task_category: string;
}

export const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [savedColleges, setSavedColleges] = useState<SavedCollege[]>([]);
  const [timelineTasks, setTimelineTasks] = useState<TimelineTask[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  const fetchDashboardData = async () => {
    try {
      // Fetch user profile
      const { data: profileData } = await supabase
        .from('user_profiles_2025_10_01_13_00')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (profileData) {
        setProfile(profileData);
      }

      // Fetch saved colleges
      const { data: collegesData } = await supabase
        .from('saved_colleges_2025_10_01_13_00')
        .select('*')
        .eq('user_id', user?.id)
        .limit(5);

      if (collegesData) {
        setSavedColleges(collegesData);
      }

      // Fetch timeline tasks
      const { data: tasksData } = await supabase
        .from('application_timeline_2025_10_01_13_00')
        .select('*')
        .eq('user_id', user?.id)
        .order('due_date', { ascending: true })
        .limit(5);

      if (tasksData) {
        setTimelineTasks(tasksData);
      }
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getApplicationProgress = () => {
    const totalTasks = timelineTasks.length;
    const completedTasks = timelineTasks.filter(task => task.completed).length;
    return totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  };

  const getUpcomingDeadlines = () => {
    const today = new Date();
    const upcoming = timelineTasks.filter(task => {
      if (!task.due_date || task.completed) return false;
      const dueDate = new Date(task.due_date);
      const diffTime = dueDate.getTime() - today.getTime();
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 30 && diffDays >= 0;
    });
    return upcoming;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  const upcomingDeadlines = getUpcomingDeadlines();
  const progress = getApplicationProgress();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {user?.user_metadata?.full_name || user?.email}!
          </h1>
          <p className="text-gray-600 mt-2">
            Track your college application progress and stay on top of deadlines
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <GraduationCap className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Saved Colleges</p>
                  <p className="text-2xl font-bold text-gray-900">{savedColleges.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <Calendar className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Upcoming Deadlines</p>
                  <p className="text-2xl font-bold text-gray-900">{upcomingDeadlines.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <CheckCircle className="h-8 w-8 text-purple-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Tasks Completed</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {timelineTasks.filter(task => task.completed).length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-orange-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Progress</p>
                  <p className="text-2xl font-bold text-gray-900">{Math.round(progress)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Application Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Application Progress
              </CardTitle>
              <CardDescription>
                Your overall progress on college applications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Overall Progress</span>
                    <span>{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {timelineTasks.filter(task => task.completed).length}
                    </div>
                    <div className="text-sm text-gray-600">Completed</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {timelineTasks.filter(task => !task.completed).length}
                    </div>
                    <div className="text-sm text-gray-600">Remaining</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Upcoming Deadlines */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertCircle className="h-5 w-5 mr-2" />
                Upcoming Deadlines
              </CardTitle>
              <CardDescription>
                Don't miss these important dates
              </CardDescription>
            </CardHeader>
            <CardContent>
              {upcomingDeadlines.length > 0 ? (
                <div className="space-y-4">
                  {upcomingDeadlines.map((task) => {
                    const dueDate = new Date(task.due_date!);
                    const today = new Date();
                    const diffTime = dueDate.getTime() - today.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    return (
                      <div key={task.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{task.task_title}</p>
                          <p className="text-sm text-gray-600">
                            {task.task_category} • Due in {diffDays} days
                          </p>
                        </div>
                        <Clock className="h-5 w-5 text-red-500" />
                      </div>
                    );
                  })}
                  <Link to="/timeline">
                    <Button variant="outline" className="w-full">
                      View All Tasks
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No upcoming deadlines</p>
                  <Link to="/timeline">
                    <Button className="mt-4">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Tasks
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Saved Colleges */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <GraduationCap className="h-5 w-5 mr-2" />
                Your College List
              </CardTitle>
              <CardDescription>
                Colleges you're considering or applying to
              </CardDescription>
            </CardHeader>
            <CardContent>
              {savedColleges.length > 0 ? (
                <div className="space-y-4">
                  {savedColleges.map((college) => (
                    <div key={college.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{college.college_name}</p>
                        <p className="text-sm text-gray-600">
                          {college.college_type} • {college.application_status}
                        </p>
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                        college.application_status === 'applied' ? 'bg-green-100 text-green-800' :
                        college.application_status === 'applying' ? 'bg-blue-100 text-blue-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {college.application_status}
                      </div>
                    </div>
                  ))}
                  <Link to="/colleges">
                    <Button variant="outline" className="w-full">
                      View All Colleges
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="text-center py-8">
                  <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No colleges saved yet</p>
                  <Link to="/colleges">
                    <Button className="mt-4">
                      <Plus className="h-4 w-4 mr-2" />
                      Explore Colleges
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>
                Common tasks to help you stay on track
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Link to="/colleges">
                  <Button variant="outline" className="w-full h-20 flex flex-col">
                    <GraduationCap className="h-6 w-6 mb-2" />
                    <span className="text-sm">Find Colleges</span>
                  </Button>
                </Link>
                
                <Link to="/fafsa">
                  <Button variant="outline" className="w-full h-20 flex flex-col">
                    <BookOpen className="h-6 w-6 mb-2" />
                    <span className="text-sm">FAFSA Guide</span>
                  </Button>
                </Link>
                
                <Link to="/timeline">
                  <Button variant="outline" className="w-full h-20 flex flex-col">
                    <Calendar className="h-6 w-6 mb-2" />
                    <span className="text-sm">Timeline</span>
                  </Button>
                </Link>
                
                <Link to="/comparison">
                  <Button variant="outline" className="w-full h-20 flex flex-col">
                    <TrendingUp className="h-6 w-6 mb-2" />
                    <span className="text-sm">Compare</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};