import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  BookOpen, 
  CheckCircle, 
  AlertCircle, 
  Calendar, 
  DollarSign, 
  FileText, 
  Users, 
  ExternalLink,
  Clock,
  Info,
  Download,
  Calculator,
  Phone,
  Mail,
  Globe,
  ArrowRight,
  Star,
  Target,
  TrendingUp,
  Shield,
  HelpCircle
} from 'lucide-react';

export const FAFSAPage: React.FC = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const markStepComplete = (stepIndex: number) => {
    if (!completedSteps.includes(stepIndex)) {
      setCompletedSteps([...completedSteps, stepIndex]);
    }
  };
  const eligibilityRequirements = [
    "U.S. citizen, U.S. national, or eligible noncitizen",
    "Valid Social Security number (with few exceptions)",
    "Enrolled or planning to enroll in eligible degree program",
    "Male students (18-25) must register with Selective Service",
    "Maintain satisfactory academic progress",
    "Not in default on federal student loans",
    "High school diploma, GED, or completion of high school in approved homeschool setting"
  ];

  const requiredDocuments = [
    {
      category: "Personal Information",
      items: [
        "Social Security number",
        "Driver's license number (if applicable)",
        "Alien Registration Number (if not a U.S. citizen)"
      ]
    },
    {
      category: "Tax Information",
      items: [
        "Federal tax returns (yours and parents' if dependent)",
        "W-2 forms and other records of money earned",
        "1099 forms (interest, dividends, unemployment)",
        "Business and investment mortgage information"
      ]
    },
    {
      category: "Financial Records",
      items: [
        "Bank account statements",
        "Investment records (stocks, bonds, mutual funds)",
        "Records of untaxed income",
        "Current balance of cash, savings, and checking accounts"
      ]
    },
    {
      category: "Benefits Information",
      items: [
        "Records of child support received",
        "Veterans benefits records",
        "Social Security benefits",
        "SNAP (food stamps) benefits"
      ]
    }
  ];

  const applicationSteps = [
    {
      step: 1,
      title: "Create FSA ID",
      description: "Visit studentaid.gov to create your Federal Student Aid ID. Both you and your parent (if dependent) need separate FSA IDs.",
      timeframe: "Before starting application",
      details: [
        "Use your legal name as it appears on your Social Security card",
        "Choose a strong password and security questions",
        "Verify your email address and phone number",
        "Keep your FSA ID information secure - it's your electronic signature"
      ],
      tips: "Your FSA ID serves as your legal signature and gives you access to Federal Student Aid websites."
    },
    {
      step: 2,
      title: "Gather Required Documents",
      description: "Collect all necessary financial documents and tax information for you and your parents (if dependent).",
      timeframe: "1-2 weeks before application",
      details: [
        "Use the IRS Data Retrieval Tool when possible",
        "Have both student and parent tax returns ready",
        "Gather bank statements from the application date",
        "Collect investment and business records"
      ],
      tips: "The IRS Data Retrieval Tool can automatically import your tax information, reducing errors and processing time."
    },
    {
      step: 3,
      title: "Complete the FAFSA Form",
      description: "Fill out the Free Application for Federal Student Aid online at studentaid.gov.",
      timeframe: "30-60 minutes",
      details: [
        "Answer all questions accurately and completely",
        "Use the IRS Data Retrieval Tool when prompted",
        "List schools in order of preference",
        "Review all information before submitting"
      ],
      tips: "Save your progress frequently and double-check all information before submitting."
    },
    {
      step: 4,
      title: "Review Student Aid Report (SAR)",
      description: "Review your SAR for accuracy and make corrections if needed.",
      timeframe: "3-5 days after submission",
      details: [
        "Check all personal and financial information",
        "Verify your Expected Family Contribution (EFC)",
        "Make corrections online if necessary",
        "Print and save a copy for your records"
      ],
      tips: "Your EFC determines your eligibility for need-based aid. A lower EFC means more aid eligibility."
    },
    {
      step: 5,
      title: "Review Financial Aid Offers",
      description: "Compare aid packages from different schools and make informed decisions.",
      timeframe: "After receiving offers",
      details: [
        "Compare total cost of attendance vs. aid offered",
        "Understand the difference between grants, loans, and work-study",
        "Consider loan terms and repayment options",
        "Accept, decline, or request changes to your aid package"
      ],
      tips: "Don't just look at the aid amount - consider the net cost and loan burden for each school."
    },
    {
      step: 6,
      title: "Complete Verification (if selected)",
      description: "Provide additional documentation if your application is selected for verification.",
      timeframe: "As soon as possible after notification",
      details: [
        "Submit requested documents promptly",
        "Provide tax transcripts from the IRS",
        "Complete verification worksheets accurately",
        "Respond to all school requests quickly"
      ],
      tips: "About 1 in 3 applications are selected for verification. Respond quickly to avoid delays in aid processing."
    }
  ];

  const commonMistakes = [
    {
      mistake: "Missing the Deadline",
      impact: "High",
      description: "Each state and school has different deadlines. Missing them can cost you thousands in aid.",
      solution: "Submit your FAFSA as early as possible, ideally by your state's priority deadline."
    },
    {
      mistake: "Not Using the IRS Data Retrieval Tool",
      impact: "Medium",
      description: "Manual entry increases errors and may trigger verification.",
      solution: "Use the IRS DRT whenever possible to import tax information directly."
    },
    {
      mistake: "Reporting Assets Incorrectly",
      impact: "High",
      description: "Including retirement accounts or primary residence can inflate your EFC.",
      solution: "Only report assets that are actually counted in the FAFSA formula."
    },
    {
      mistake: "Not Listing Schools in Order of Preference",
      impact: "Medium",
      description: "Some states award aid based on school ranking on your FAFSA.",
      solution: "List your top choice school first, especially for state aid programs."
    },
    {
      mistake: "Ignoring Verification Requests",
      impact: "High",
      description: "Not responding to verification can result in loss of all financial aid.",
      solution: "Respond to verification requests immediately with accurate documentation."
    }
  ];

  const aidTypes = [
    {
      type: "Federal Pell Grant",
      amount: "Up to $7,395 (2023-24)",
      description: "Need-based grant that doesn't need to be repaid",
      eligibility: "Undergraduate students with exceptional financial need",
      renewable: true
    },
    {
      type: "Federal Supplemental Educational Opportunity Grant (FSEOG)",
      amount: "$100 - $4,000",
      description: "Additional need-based grant for students with lowest EFC",
      eligibility: "Undergraduate students with exceptional financial need",
      renewable: true
    },
    {
      type: "Direct Subsidized Loans",
      amount: "Up to $5,500 (freshmen)",
      description: "Government pays interest while you're in school",
      eligibility: "Undergraduate students with financial need",
      renewable: true
    },
    {
      type: "Direct Unsubsidized Loans",
      amount: "Up to $12,500 (independent students)",
      description: "Not based on need, but interest accrues while in school",
      eligibility: "All students regardless of need",
      renewable: true
    },
    {
      type: "Federal Work-Study",
      amount: "Varies by school",
      description: "Part-time employment to help pay education expenses",
      eligibility: "Students with financial need",
      renewable: true
    },
    {
      type: "Parent PLUS Loans",
      amount: "Up to cost of attendance minus other aid",
      description: "Federal loans for parents of dependent students",
      eligibility: "Parents who pass credit check",
      renewable: true
    }
  ];

  const stateDeadlines = [
    { state: "California", deadline: "March 2", priority: "High", notes: "Cal Grant deadline" },
    { state: "Texas", deadline: "March 15", priority: "High", notes: "TEXAS Grant priority" },
    { state: "New York", deadline: "May 1", priority: "Medium", notes: "TAP application" },
    { state: "Florida", deadline: "May 15", priority: "Medium", notes: "Florida Student Aid" },
    { state: "Illinois", deadline: "March 1", priority: "High", notes: "MAP Grant priority" },
    { state: "Pennsylvania", deadline: "May 1", priority: "Medium", notes: "State grant programs" },
    { state: "Ohio", deadline: "October 1", priority: "Medium", notes: "Ohio College Opportunity Grant" },
    { state: "Michigan", deadline: "March 1", priority: "High", notes: "Michigan Competitive Scholarship" }
  ];

  const citizenshipStatuses = [
    {
      status: "U.S. Citizen",
      fafsaEligible: true,
      description: "Full FAFSA eligibility for all federal aid programs",
      aidTypes: ["Pell Grant", "Federal loans", "Work-study", "State aid"]
    },
    {
      status: "Permanent Resident (Green Card)",
      fafsaEligible: true,
      description: "Full FAFSA eligibility same as U.S. citizens",
      aidTypes: ["Pell Grant", "Federal loans", "Work-study", "State aid"]
    },
    {
      status: "F-1 Visa Student",
      fafsaEligible: false,
      description: "Not eligible for FAFSA. Must seek institutional aid",
      aidTypes: ["College scholarships", "Private scholarships", "Institutional aid"]
    },
    {
      status: "J-1 Visa Student",
      fafsaEligible: false,
      description: "Not eligible for FAFSA. Limited aid options available",
      aidTypes: ["College scholarships", "Private scholarships", "Sponsor funding"]
    }
  ];

  const alternativeAid = [
    {
      title: "Institutional Scholarships",
      description: "Merit and need-based aid directly from colleges",
      eligibility: "All students including internationals",
      application: "Usually through college application"
    },
    {
      title: "Private Scholarships",
      description: "Scholarships from organizations, foundations, and companies",
      eligibility: "Varies by scholarship",
      application: "Separate applications required"
    },
    {
      title: "State Aid Programs",
      description: "Financial aid from individual state governments",
      eligibility: "Usually requires state residency",
      application: "Often through FAFSA or state forms"
    },
    {
      title: "Work-Study Programs",
      description: "Part-time employment to help pay education costs",
      eligibility: "Federal and institutional programs available",
      application: "Through FAFSA or college financial aid office"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">FAFSA Guide</h1>
          <p className="text-gray-600">
            Complete guide to the Free Application for Federal Student Aid (FAFSA) and financial aid options
          </p>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="eligibility">Eligibility</TabsTrigger>
            <TabsTrigger value="application">How to Apply</TabsTrigger>
            <TabsTrigger value="citizenship">Citizenship</TabsTrigger>
            <TabsTrigger value="alternatives">Alternatives</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-8">
            <div className="grid lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-2" />
                    What is FAFSA?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 mb-4">
                    FAFSA is a form used by students in the United States to apply for financial aid for college or university. 
                    It determines eligibility for federal aid such as grants, loans, and work-study programs.
                  </p>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span>Free to complete</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span>Required for federal aid</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span>Used by states and colleges</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                      <span>Must be completed annually</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    Important Dates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-blue-500 pl-4">
                      <h4 className="font-semibold text-blue-700">October 1</h4>
                      <p className="text-gray-600">FAFSA opens for the following academic year</p>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4">
                      <h4 className="font-semibold text-green-700">As Soon as Possible</h4>
                      <p className="text-gray-600">Submit early - some aid is first-come, first-served</p>
                    </div>
                    <div className="border-l-4 border-red-500 pl-4">
                      <h4 className="font-semibold text-red-700">June 30</h4>
                      <p className="text-gray-600">Federal deadline for FAFSA submission</p>
                    </div>
                    <div className="border-l-4 border-orange-500 pl-4">
                      <h4 className="font-semibold text-orange-700">State Deadlines</h4>
                      <p className="text-gray-600">Vary by state - check your state's deadline</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Alert className="mt-8">
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>Important:</strong> FAFSA is only available to U.S. citizens, permanent residents, and certain eligible noncitizens. 
                International students on F-1 or J-1 visas are not eligible for FAFSA but may qualify for institutional aid.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="eligibility" className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>FAFSA Eligibility Requirements</CardTitle>
                <CardDescription>
                  You must meet all of these requirements to be eligible for federal student aid
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold mb-4">Basic Requirements</h4>
                    <div className="space-y-3">
                      {eligibilityRequirements.map((requirement, index) => (
                        <div key={index} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{requirement}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-4">Additional Considerations</h4>
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h5 className="font-medium text-blue-900 mb-2">Dependency Status</h5>
                        <p className="text-blue-700 text-sm">
                          Most undergraduate students are considered dependent and must provide parent information
                        </p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <h5 className="font-medium text-green-900 mb-2">Financial Need</h5>
                        <p className="text-green-700 text-sm">
                          Aid is based on financial need calculated from your FAFSA information
                        </p>
                      </div>
                      <div className="p-4 bg-orange-50 rounded-lg">
                        <h5 className="font-medium text-orange-900 mb-2">Academic Progress</h5>
                        <p className="text-orange-700 text-sm">
                          Must maintain satisfactory academic progress to continue receiving aid
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="application" className="mt-8">
            <div className="space-y-8">
              <Card>
                <CardHeader>
                  <CardTitle>Step-by-Step Application Process</CardTitle>
                  <CardDescription>
                    Follow these steps to complete your FAFSA application successfully
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {applicationSteps.map((step) => (
                      <div key={step.step} className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-semibold">
                          {step.step}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">{step.title}</h4>
                          <p className="text-gray-600 mb-2">{step.description}</p>
                          <Badge variant="outline" className="text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            {step.timeframe}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Required Documents
                  </CardTitle>
                  <CardDescription>
                    Gather these documents before starting your FAFSA
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {requiredDocuments.map((document, index) => (
                      <div key={index} className="flex items-center p-3 bg-gray-50 rounded-lg">
                        <FileText className="h-4 w-4 text-blue-600 mr-3" />
                        <span className="text-gray-700">{document}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <div className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-yellow-600 mr-2 mt-0.5" />
                      <div>
                        <h5 className="font-medium text-yellow-800 mb-1">Pro Tip</h5>
                        <p className="text-yellow-700 text-sm">
                          If you're a dependent student, you'll also need your parents' financial information and documents.
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="citizenship" className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Citizenship Status and FAFSA Eligibility</CardTitle>
                <CardDescription>
                  Understanding how your citizenship status affects financial aid eligibility
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-6">
                  {citizenshipStatuses.map((status) => (
                    <div key={status.status} className={`p-6 border-2 rounded-lg ${
                      status.fafsaEligible ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                    }`}>
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h4 className="font-semibold text-lg text-gray-900">{status.status}</h4>
                          <p className="text-gray-600 mt-1">{status.description}</p>
                        </div>
                        <Badge variant={status.fafsaEligible ? "default" : "destructive"}>
                          {status.fafsaEligible ? "FAFSA Eligible" : "Not FAFSA Eligible"}
                        </Badge>
                      </div>
                      
                      <div>
                        <h5 className="font-medium text-gray-900 mb-2">Available Aid Types:</h5>
                        <div className="flex flex-wrap gap-2">
                          {status.aidTypes.map((aid) => (
                            <Badge key={aid} variant="outline" className="text-xs">
                              {aid}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="alternatives" className="mt-8">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Alternative Financial Aid Options</CardTitle>
                  <CardDescription>
                    Financial aid options for students who don't qualify for FAFSA
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    {alternativeAid.map((aid) => (
                      <div key={aid.title} className="p-6 border border-gray-200 rounded-lg">
                        <h4 className="font-semibold text-gray-900 mb-2">{aid.title}</h4>
                        <p className="text-gray-600 mb-4">{aid.description}</p>
                        
                        <div className="space-y-2">
                          <div>
                            <span className="text-sm font-medium text-gray-700">Eligibility: </span>
                            <span className="text-sm text-gray-600">{aid.eligibility}</span>
                          </div>
                          <div>
                            <span className="text-sm font-medium text-gray-700">Application: </span>
                            <span className="text-sm text-gray-600">{aid.application}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Scholarship Search Resources</CardTitle>
                  <CardDescription>
                    Recommended websites and resources for finding scholarships
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <h5 className="font-medium mb-2">Fastweb</h5>
                      <p className="text-sm text-gray-600 mb-3">Comprehensive scholarship database</p>
                      <Button variant="outline" size="sm" asChild>
                        <a href="https://www.fastweb.com" target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          Visit Site
                        </a>
                      </Button>
                    </div>
                    
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <h5 className="font-medium mb-2">Scholarships.com</h5>
                      <p className="text-sm text-gray-600 mb-3">Free scholarship matching service</p>
                      <Button variant="outline" size="sm" asChild>
                        <a href="https://www.scholarships.com" target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          Visit Site
                        </a>
                      </Button>
                    </div>
                    
                    <div className="p-4 border border-gray-200 rounded-lg text-center">
                      <h5 className="font-medium mb-2">College Board</h5>
                      <p className="text-sm text-gray-600 mb-3">Scholarship search and planning tools</p>
                      <Button variant="outline" size="sm" asChild>
                        <a href="https://bigfuture.collegeboard.org/pay-for-college/scholarship-search" target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          Visit Site
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};