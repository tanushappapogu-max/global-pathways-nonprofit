import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { 
  GraduationCap, 
  Globe, 
  DollarSign, 
  Calendar, 
  BarChart3, 
  Users, 
  BookOpen, 
  Clock,
  ArrowRight
} from 'lucide-react';

const Index = () => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const studentTypes = [
    {
      type: 'international',
      title: t('home.international'),
      description: 'Guidance for F-1, J-1 visa students and international applicants',
      icon: Globe,
      color: 'bg-blue-50 text-blue-600 border-blue-200',
      features: ['Visa guidance', 'TOEFL/IELTS prep', 'Cultural adaptation', 'No FAFSA eligibility info']
    },
    {
      type: 'low_income',
      title: t('home.low_income'),
      description: 'Financial aid resources and scholarship opportunities',
      icon: DollarSign,
      color: 'bg-green-50 text-green-600 border-green-200',
      features: ['FAFSA guidance', 'Need-based aid', 'Fee waivers', 'Work-study programs']
    },
    {
      type: 'first_generation',
      title: t('home.first_gen'),
      description: 'Support for students whose parents didn\'t attend college',
      icon: Users,
      color: 'bg-purple-50 text-purple-600 border-purple-200',
      features: ['College basics', 'Family guidance', 'Mentorship', 'Support networks']
    }
  ];

  const features = [
    {
      icon: BookOpen,
      title: t('features.fafsa'),
      description: t('features.fafsa_desc')
    },
    {
      icon: GraduationCap,
      title: t('features.colleges'),
      description: t('features.colleges_desc')
    },
    {
      icon: Clock,
      title: t('features.timeline'),
      description: t('features.timeline_desc')
    },
    {
      icon: BarChart3,
      title: t('features.comparison'),
      description: t('features.comparison_desc')
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              {t('home.title')}
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-blue-100">
              {t('home.subtitle')}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {user ? (
                <Link to="/dashboard">
                  <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                    Go to Dashboard
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              ) : (
                <>
                  <Link to="/signup">
                    <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                      {t('home.cta')}
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                  <Link to="/colleges">
                    <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                      Explore Colleges
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Student Types Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('home.student_types')}
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get personalized guidance based on your unique situation and needs
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {studentTypes.map((type) => {
              const IconComponent = type.icon;
              return (
                <Card key={type.type} className={`border-2 hover:shadow-lg transition-all duration-300 ${type.color}`}>
                  <CardHeader className="text-center">
                    <div className="mx-auto mb-4 p-3 rounded-full bg-white">
                      <IconComponent className="h-8 w-8" />
                    </div>
                    <CardTitle className="text-xl">{type.title}</CardTitle>
                    <CardDescription className="text-gray-600">
                      {type.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {type.features.map((feature, index) => (
                        <li key={index} className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-current rounded-full mr-3"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <Link to={user ? "/dashboard" : "/signup"}>
                      <Button className="w-full">
                        Get Started
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              {t('features.title')}
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools and resources to guide you through every step of the college application process
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="mx-auto mb-4 p-4 bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center">
                    <IconComponent className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Hero Images Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Join a Community of Success
              </h2>
              <p className="text-lg text-gray-600 mb-8">
                Connect with thousands of students who have successfully navigated the US college admissions process. 
                Get personalized guidance, track your progress, and achieve your dreams of studying in America.
              </p>
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-3xl font-bold text-blue-600">2,847+</div>
                  <div className="text-sm text-gray-600">Students Helped</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">$2.1M+</div>
                  <div className="text-sm text-gray-600">Aid Unlocked</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">1,956+</div>
                  <div className="text-sm text-gray-600">FAFSA Completions</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-blue-600">50+</div>
                  <div className="text-sm text-gray-600">Partner Schools</div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img 
                src="/images/students_studying_1.jpeg" 
                alt="Diverse students studying together"
                className="rounded-lg shadow-lg"
              />
              <img 
                src="/images/college_campus_1.jpeg" 
                alt="Beautiful college campus"
                className="rounded-lg shadow-lg mt-8"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your College Journey?
          </h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of students who have successfully gained admission to top US universities
          </p>
          {!user && (
            <Link to="/signup">
              <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50">
                Create Your Free Account
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          )}
        </div>
      </section>
    </div>
  );
};

export default Index;