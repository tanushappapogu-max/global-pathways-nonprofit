import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { 
  Users, 
  FileText, 
  DollarSign, 
  Building, 
  TrendingUp, 
  Heart,
  Star,
  Quote
} from 'lucide-react';

interface ImpactMetric {
  metric_name: string;
  metric_value: number;
  updated_at: string;
}

interface Testimonial {
  id: string;
  student_name: string;
  student_class?: string;
  testimonial_text: string;
  aid_amount?: number;
}

interface Partner {
  id: string;
  partner_name: string;
  partner_type: string;
  logo_url?: string;
  website_url?: string;
}

export const ImpactPage: React.FC = () => {
  const [metrics, setMetrics] = useState<ImpactMetric[]>([]);
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchImpactData();
  }, []);

  const fetchImpactData = async () => {
    try {
      // Fetch impact metrics
      const { data: metricsData } = await supabase
        .from('impact_metrics_2025_10_06_00_42')
        .select('*');

      // Fetch testimonials
      const { data: testimonialsData } = await supabase
        .from('testimonials_2025_10_06_00_42')
        .select('*')
        .eq('is_featured', true)
        .eq('is_approved', true)
        .limit(6);

      // Fetch partners
      const { data: partnersData } = await supabase
        .from('partners_2025_10_06_00_42')
        .select('*')
        .eq('is_active', true)
        .limit(12);

      if (metricsData) setMetrics(metricsData);
      if (testimonialsData) setTestimonials(testimonialsData);
      if (partnersData) setPartners(partnersData);
    } catch (error) {
      console.error('Error fetching impact data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMetricValue = (metricName: string): number => {
    const metric = metrics.find(m => m.metric_name === metricName);
    return metric ? metric.metric_value : 0;
  };

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatNumber = (num: number): string => {
    return new Intl.NumberFormat('en-US').format(num);
  };

  const impactStats = [
    {
      title: 'Students Helped',
      value: getMetricValue('students_helped'),
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-100',
      description: 'Students who have used our platform'
    },
    {
      title: 'FAFSA Submissions',
      value: getMetricValue('fafsa_submissions'),
      icon: FileText,
      color: 'text-green-600',
      bgColor: 'bg-green-100',
      description: 'Completed FAFSA applications'
    },
    {
      title: 'Aid Unlocked',
      value: getMetricValue('total_aid_unlocked'),
      icon: DollarSign,
      color: 'text-purple-600',
      bgColor: 'bg-purple-100',
      description: 'Total financial aid secured',
      isCurrency: true
    },
    {
      title: 'Partner Organizations',
      value: getMetricValue('partner_organizations'),
      icon: Building,
      color: 'text-orange-600',
      bgColor: 'bg-orange-100',
      description: 'Schools and organizations we work with'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading impact data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Impact</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See how Global Pathways is transforming college access for students worldwide
          </p>
        </div>

        {/* Impact Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {impactStats.map((stat) => {
            const IconComponent = stat.icon;
            return (
              <Card key={stat.title} className="text-center">
                <CardContent className="pt-6">
                  <div className={`mx-auto mb-4 p-4 rounded-full w-16 h-16 flex items-center justify-center ${stat.bgColor}`}>
                    <IconComponent className={`h-8 w-8 ${stat.color}`} />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">
                    {stat.isCurrency ? formatCurrency(stat.value) : formatNumber(stat.value)}
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {stat.title}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {stat.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Success Stories */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-lg text-gray-600">
              Real stories from students who achieved their college dreams with Global Pathways
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="h-full">
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    <Quote className="h-8 w-8 text-blue-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.student_name}</h4>
                      {testimonial.student_class && (
                        <p className="text-sm text-gray-600">{testimonial.student_class}</p>
                      )}
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-4 italic">
                    "{testimonial.testimonial_text}"
                  </p>
                  
                  {testimonial.aid_amount && testimonial.aid_amount > 0 && (
                    <div className="flex items-center">
                      <DollarSign className="h-4 w-4 text-green-600 mr-1" />
                      <span className="text-sm font-medium text-green-600">
                        {formatCurrency(testimonial.aid_amount)} in aid received
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Partner Organizations */}
        <section className="mb-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Partners</h2>
            <p className="text-lg text-gray-600">
              Working together with schools and organizations to expand college access
            </p>
          </div>

          <Card>
            <CardContent className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {partners.map((partner) => (
                  <div key={partner.id} className="text-center p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                    <div className="mb-3">
                      {partner.logo_url ? (
                        <img 
                          src={partner.logo_url} 
                          alt={partner.partner_name}
                          className="h-12 w-auto mx-auto"
                        />
                      ) : (
                        <div className="h-12 w-12 bg-gray-200 rounded-full mx-auto flex items-center justify-center">
                          <Building className="h-6 w-6 text-gray-500" />
                        </div>
                      )}
                    </div>
                    <h4 className="font-medium text-gray-900 text-sm mb-1">
                      {partner.partner_name}
                    </h4>
                    <Badge variant="outline" className="text-xs">
                      {partner.partner_type.replace('_', ' ')}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Call to Action */}
        <section className="text-center bg-blue-600 text-white rounded-lg p-12">
          <h2 className="text-3xl font-bold mb-4">Join Our Growing Community</h2>
          <p className="text-xl mb-8 text-blue-100">
            Be part of the next success story. Start your college journey with Global Pathways today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/signup" 
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors"
            >
              Get Started Free
            </a>
            <a 
              href="/counselor-signup" 
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Join as Counselor
            </a>
          </div>
        </section>

        {/* Real-time Updates Notice */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-500">
            <TrendingUp className="h-4 w-4 inline mr-1" />
            Impact metrics updated in real-time as students complete their applications
          </p>
        </div>
      </div>
    </div>
  );
};