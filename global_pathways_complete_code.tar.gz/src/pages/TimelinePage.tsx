import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  Calendar, 
  Plus, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Edit, 
  Trash2,
  Filter
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface TimelineTask {
  id: string;
  task_title: string;
  task_description?: string;
  due_date?: string;
  completed: boolean;
  college_name?: string;
  task_category: string;
  created_at: string;
}

export const TimelinePage: React.FC = () => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<TimelineTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Form state
  const [newTask, setNewTask] = useState({
    task_title: '',
    task_description: '',
    due_date: '',
    college_name: '',
    task_category: 'other'
  });

  useEffect(() => {
    if (user) {
      fetchTasks();
    }
  }, [user]);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('application_timeline_2025_10_01_13_00')
        .select('*')
        .eq('user_id', user?.id)
        .order('due_date', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      toast({
        title: "Error",
        description: "Failed to load timeline tasks",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const addTask = async () => {
    if (!newTask.task_title.trim()) {
      toast({
        title: "Error",
        description: "Task title is required",
        variant: "destructive",
      });
      return;
    }

    try {
      const { data, error } = await supabase
        .from('application_timeline_2025_10_01_13_00')
        .insert({
          user_id: user?.id,
          task_title: newTask.task_title,
          task_description: newTask.task_description || null,
          due_date: newTask.due_date || null,
          college_name: newTask.college_name || null,
          task_category: newTask.task_category,
          completed: false
        })
        .select()
        .single();

      if (error) throw error;

      setTasks([...tasks, data]);
      setNewTask({
        task_title: '',
        task_description: '',
        due_date: '',
        college_name: '',
        task_category: 'other'
      });
      setIsAddingTask(false);

      toast({
        title: "Task Added",
        description: "New task has been added to your timeline",
      });
    } catch (error) {
      console.error('Error adding task:', error);
      toast({
        title: "Error",
        description: "Failed to add task",
        variant: "destructive",
      });
    }
  };

  const toggleTaskCompletion = async (taskId: string, completed: boolean) => {
    try {
      const { error } = await supabase
        .from('application_timeline_2025_10_01_13_00')
        .update({ completed: !completed })
        .eq('id', taskId);

      if (error) throw error;

      setTasks(tasks.map(task => 
        task.id === taskId ? { ...task, completed: !completed } : task
      ));

      toast({
        title: completed ? "Task Marked Incomplete" : "Task Completed",
        description: completed ? "Task marked as incomplete" : "Great job completing this task!",
      });
    } catch (error) {
      console.error('Error updating task:', error);
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive",
      });
    }
  };

  const deleteTask = async (taskId: string) => {
    try {
      const { error } = await supabase
        .from('application_timeline_2025_10_01_13_00')
        .delete()
        .eq('id', taskId);

      if (error) throw error;

      setTasks(tasks.filter(task => task.id !== taskId));

      toast({
        title: "Task Deleted",
        description: "Task has been removed from your timeline",
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive",
      });
    }
  };

  const getTasksByMonth = () => {
    const tasksByMonth: { [key: string]: TimelineTask[] } = {};
    
    tasks.forEach(task => {
      if (task.due_date) {
        const date = new Date(task.due_date);
        const monthKey = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long' });
        
        if (!tasksByMonth[monthKey]) {
          tasksByMonth[monthKey] = [];
        }
        tasksByMonth[monthKey].push(task);
      }
    });

    return tasksByMonth;
  };

  const filteredTasks = tasks.filter(task => {
    const categoryMatch = filterCategory === 'all' || task.task_category === filterCategory;
    const statusMatch = filterStatus === 'all' || 
                       (filterStatus === 'completed' && task.completed) ||
                       (filterStatus === 'pending' && !task.completed);
    return categoryMatch && statusMatch;
  });

  const getTaskPriority = (task: TimelineTask) => {
    if (!task.due_date) return 'low';
    
    const today = new Date();
    const dueDate = new Date(task.due_date);
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return 'overdue';
    if (diffDays <= 7) return 'high';
    if (diffDays <= 30) return 'medium';
    return 'low';
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'overdue': return 'bg-red-100 border-red-300 text-red-800';
      case 'high': return 'bg-orange-100 border-orange-300 text-orange-800';
      case 'medium': return 'bg-yellow-100 border-yellow-300 text-yellow-800';
      default: return 'bg-green-100 border-green-300 text-green-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading your timeline...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Application Timeline</h1>
            <p className="text-gray-600 mt-2">
              Track your college application tasks and deadlines
            </p>
          </div>
          
          <Dialog open={isAddingTask} onOpenChange={setIsAddingTask}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Task</DialogTitle>
                <DialogDescription>
                  Create a new task for your college application timeline
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="task_title">Task Title *</Label>
                  <Input
                    id="task_title"
                    value={newTask.task_title}
                    onChange={(e) => setNewTask({...newTask, task_title: e.target.value})}
                    placeholder="e.g., Submit Common Application"
                  />
                </div>
                
                <div>
                  <Label htmlFor="task_description">Description</Label>
                  <Textarea
                    id="task_description"
                    value={newTask.task_description}
                    onChange={(e) => setNewTask({...newTask, task_description: e.target.value})}
                    placeholder="Additional details about this task..."
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="due_date">Due Date</Label>
                    <Input
                      id="due_date"
                      type="date"
                      value={newTask.due_date}
                      onChange={(e) => setNewTask({...newTask, due_date: e.target.value})}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="task_category">Category</Label>
                    <Select value={newTask.task_category} onValueChange={(value) => setNewTask({...newTask, task_category: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="testing">Testing</SelectItem>
                        <SelectItem value="applications">Applications</SelectItem>
                        <SelectItem value="financial_aid">Financial Aid</SelectItem>
                        <SelectItem value="essays">Essays</SelectItem>
                        <SelectItem value="recommendations">Recommendations</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="college_name">College (Optional)</Label>
                  <Input
                    id="college_name"
                    value={newTask.college_name}
                    onChange={(e) => setNewTask({...newTask, college_name: e.target.value})}
                    placeholder="e.g., Harvard University"
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddingTask(false)}>
                    Cancel
                  </Button>
                  <Button onClick={addTask}>
                    Add Task
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-500" />
                <span className="text-sm font-medium">Filters:</span>
              </div>
              
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="testing">Testing</SelectItem>
                  <SelectItem value="applications">Applications</SelectItem>
                  <SelectItem value="financial_aid">Financial Aid</SelectItem>
                  <SelectItem value="essays">Essays</SelectItem>
                  <SelectItem value="recommendations">Recommendations</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-32">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Tasks</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="ml-auto text-sm text-gray-500">
                {filteredTasks.length} tasks
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tasks List */}
        {filteredTasks.length > 0 ? (
          <div className="space-y-4">
            {filteredTasks.map((task) => {
              const priority = getTaskPriority(task);
              const priorityColor = getPriorityColor(priority);
              
              return (
                <Card key={task.id} className={`${task.completed ? 'opacity-75' : ''} ${priorityColor}`}>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4 flex-1">
                        <Checkbox
                          checked={task.completed}
                          onCheckedChange={() => toggleTaskCompletion(task.id, task.completed)}
                          className="mt-1"
                        />
                        
                        <div className="flex-1">
                          <h3 className={`font-semibold ${task.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                            {task.task_title}
                          </h3>
                          
                          {task.task_description && (
                            <p className={`text-sm mt-1 ${task.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                              {task.task_description}
                            </p>
                          )}
                          
                          <div className="flex items-center space-x-4 mt-3">
                            {task.due_date && (
                              <div className="flex items-center text-sm text-gray-500">
                                <Calendar className="h-4 w-4 mr-1" />
                                {new Date(task.due_date).toLocaleDateString()}
                              </div>
                            )}
                            
                            <Badge variant="outline" className="text-xs">
                              {task.task_category}
                            </Badge>
                            
                            {task.college_name && (
                              <Badge variant="secondary" className="text-xs">
                                {task.college_name}
                              </Badge>
                            )}
                            
                            {priority === 'overdue' && (
                              <Badge variant="destructive" className="text-xs">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Overdue
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteTask(task.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <Clock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No tasks found</h3>
              <p className="text-gray-600 mb-6">
                {tasks.length === 0 
                  ? "Start by adding your first application task"
                  : "No tasks match your current filters"
                }
              </p>
              {tasks.length === 0 && (
                <Button onClick={() => setIsAddingTask(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Task
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};