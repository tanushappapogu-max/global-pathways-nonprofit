import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { 
  Building, 
  ExternalLink, 
  Mail, 
  Users, 
  GraduationCap,
  BookOpen,
  MapPin,
  Heart,
  Handshake,
  Star
} from 'lucide-react';

interface Partner {
  id: string;
  partner_name: string;
  partner_type: string;
  logo_url?: string;
  website_url?: string;
  contact_email?: string;
  is_active: boolean;
  created_at: string;
}

export const PartnersPage: React.FC = () => {
  const [partners, setPartners] = useState<Partner[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPartners();
  }, []);

  const fetchPartners = async () => {
    try {
      const { data, error } = await supabase
        .from('partners_2025_10_06_00_42')
        .select('*')
        .eq('is_active', true)
        .order('partner_name', { ascending: true });

      if (error) throw error;
      setPartners(data || []);
    } catch (error) {
      console.error('Error fetching partners:', error);
    } finally {
      setLoading(false);
    }
  };

  const getPartnersByType = () => {
    const grouped: { [key: string]: Partner[] } = {};
    partners.forEach(partner => {
      if (!grouped[partner.partner_type]) {
        grouped[partner.partner_type] = [];
      }
      grouped[partner.partner_type].push(partner);
    });
    return grouped;
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'high_school': return <GraduationCap className="h-6 w-6" />;
      case 'nonprofit': return <Heart className="h-6 w-6" />;
      case 'library': return <BookOpen className="h-6 w-6" />;
      case 'community_center': return <Users className="h-6 w-6" />;
      default: return <Building className="h-6 w-6" />;
    }
  };

  const getTypeTitle = (type: string) => {
    switch (type) {
      case 'high_school': return 'High Schools';
      case 'nonprofit': return 'Nonprofit Organizations';
      case 'library': return 'Libraries';
      case 'community_center': return 'Community Centers';
      default: return 'Other Partners';
    }
  };

  const getTypeDescription = (type: string) => {
    switch (type) {
      case 'high_school': return 'Educational institutions helping students navigate college admissions';
      case 'nonprofit': return 'Organizations dedicated to expanding educational opportunities';
      case 'library': return 'Public libraries providing college planning resources';
      case 'community_center': return 'Community centers supporting local students';
      default: return 'Other organizations supporting our mission';
    }
  };

  const advisoryBoard = [
    {
      name: 'Dr. Sarah Johnson',
      title: 'Former Financial Aid Director, State University',
      bio: 'Over 20 years of experience in financial aid administration and student support services.',
      image: '/images/advisor1.jpg'
    },
    {
      name: 'Maria Rodriguez',
      title: 'High School Counselor, Lincoln High School',
      bio: 'Dedicated counselor helping first-generation college students navigate the admissions process.',
      image: '/images/advisor2.jpg'
    },
    {
      name: 'James Chen',
      title: 'College Access Program Director',
      bio: 'Leading initiatives to increase college enrollment among underrepresented students.',
      image: '/images/advisor3.jpg'
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading partners...</p>
        </div>
      </div>
    );
  }

  const partnersByType = getPartnersByType();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Partners</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Working together with schools, organizations, and communities to expand college access for all students
          </p>
        </div>

        {/* Partnership Impact */}
        <section className="mb-16">
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardContent className="pt-8 pb-8">
              <div className="grid md:grid-cols-3 gap-8 text-center">
                <div>
                  <div className="text-4xl font-bold mb-2">{partners.length}+</div>
                  <p className="text-blue-100">Partner Organizations</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">50K+</div>
                  <p className="text-blue-100">Students Reached</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">$26M+</div>
                  <p className="text-blue-100">Aid Unlocked</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Partner Organizations */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Partner Organizations</h2>
            <p className="text-lg text-gray-600">
              Schools and organizations that trust Global Pathways to support their students
            </p>
          </div>

          <div className="space-y-12">
            {Object.entries(partnersByType).map(([type, typePartners]) => (
              <div key={type}>
                <div className="flex items-center mb-6">
                  <div className="p-3 bg-blue-100 rounded-full mr-4">
                    {getTypeIcon(type)}
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{getTypeTitle(type)}</h3>
                    <p className="text-gray-600">{getTypeDescription(type)}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {typePartners.map((partner) => (
                    <Card key={partner.id} className="hover:shadow-lg transition-shadow">
                      <CardContent className="pt-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            {partner.logo_url ? (
                              <img
                                src={partner.logo_url}
                                alt={partner.partner_name}
                                className="h-12 w-auto mb-3"
                              />
                            ) : (
                              <div className="h-12 w-12 bg-gray-200 rounded-lg flex items-center justify-center mb-3">
                                {getTypeIcon(partner.partner_type)}
                              </div>
                            )}
                            <h4 className="font-semibold text-gray-900 mb-2">
                              {partner.partner_name}
                            </h4>
                            <Badge variant="outline" className="text-xs">
                              {partner.partner_type.replace('_', ' ')}
                            </Badge>
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          {partner.website_url && (
                            <Button variant="outline" size="sm" asChild>
                              <a
                                href={partner.website_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center"
                              >
                                <ExternalLink className="h-4 w-4 mr-1" />
                                Visit
                              </a>
                            </Button>
                          )}
                          {partner.contact_email && (
                            <Button variant="outline" size="sm" asChild>
                              <a
                                href={`mailto:${partner.contact_email}`}
                                className="flex items-center"
                              >
                                <Mail className="h-4 w-4 mr-1" />
                                Contact
                              </a>
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Advisory Board */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Advisory Board</h2>
            <p className="text-lg text-gray-600">
              Experienced educators and financial aid professionals guiding our mission
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {advisoryBoard.map((advisor, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <User className="h-12 w-12 text-white" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-1">{advisor.name}</h4>
                  <p className="text-blue-600 font-medium mb-3">{advisor.title}</p>
                  <p className="text-gray-600 text-sm">{advisor.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Partnership Benefits */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Partnership Benefits</h2>
            <p className="text-lg text-gray-600">
              What our partners gain by working with Global Pathways
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-8 w-8 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Student Support</h4>
                <p className="text-gray-600 text-sm">
                  Enhanced resources and tools for your students' college journey
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Star className="h-8 w-8 text-green-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Improved Outcomes</h4>
                <p className="text-gray-600 text-sm">
                  Higher FAFSA completion rates and college enrollment success
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <BookOpen className="h-8 w-8 text-purple-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Training & Resources</h4>
                <p className="text-gray-600 text-sm">
                  Professional development and educational materials for staff
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Handshake className="h-8 w-8 text-orange-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Community Impact</h4>
                <p className="text-gray-600 text-sm">
                  Be part of a movement expanding college access nationwide
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Become a Partner CTA */}
        <section className="text-center bg-blue-600 text-white rounded-lg p-12">
          <h2 className="text-3xl font-bold mb-4">Become a Partner</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Join our network of organizations committed to expanding college access and helping students achieve their dreams
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-blue-600 hover:bg-blue-50">
              <Mail className="h-4 w-4 mr-2" />
              Contact Us
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <ExternalLink className="h-4 w-4 mr-2" />
              Partnership Info
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
};

// Fix missing User import
const User = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
  </svg>
);