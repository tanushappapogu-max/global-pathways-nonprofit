import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Target, 
  Heart, 
  Award, 
  Globe, 
  BookOpen,
  TrendingUp,
  Mail,
  ExternalLink,
  Star
} from 'lucide-react';

export const AboutPage: React.FC = () => {
  const teamMembers = [
    {
      name: 'Alex Johnson',
      role: 'Founder & CEO',
      bio: 'Passionate about democratizing college access. Former first-generation college student who understands the challenges of navigating higher education.',
      image: '/images/team1.jpg',
      skills: ['Leadership', 'Product Strategy', 'Student Advocacy']
    },
    {
      name: 'Sarah Kim',
      role: 'Head of Technology',
      bio: 'Full-stack developer with expertise in educational technology. Committed to building accessible and user-friendly platforms.',
      image: '/images/team2.jpg',
      skills: ['React', 'Node.js', 'Database Design']
    },
    {
      name: 'Maria Rodriguez',
      role: 'Director of Outreach',
      bio: 'Former high school counselor with 10+ years of experience helping students with college applications and financial aid.',
      image: '/images/team3.jpg',
      skills: ['Community Engagement', 'Partnership Development', 'Student Counseling']
    },
    {
      name: 'David Chen',
      role: 'Content & Translation Lead',
      bio: 'Multilingual educator focused on making college resources accessible to diverse communities worldwide.',
      image: '/images/team4.jpg',
      skills: ['Content Strategy', 'Translation', 'Cultural Adaptation']
    }
  ];

  const milestones = [
    {
      year: '2023',
      title: 'Platform Launch',
      description: 'Global Pathways launched with basic FAFSA guidance and college information.',
      icon: <BookOpen className="h-6 w-6" />
    },
    {
      year: '2024',
      title: 'Multilingual Support',
      description: 'Added support for Spanish, Hindi, Mandarin, Arabic, and French translations.',
      icon: <Globe className="h-6 w-6" />
    },
    {
      year: '2024',
      title: 'Counselor Portal',
      description: 'Launched dedicated portal for high school counselors to track student progress.',
      icon: <Users className="h-6 w-6" />
    },
    {
      year: '2024',
      title: 'Major Partnerships',
      description: 'Established partnerships with 50+ schools and nonprofit organizations.',
      icon: <Award className="h-6 w-6" />
    }
  ];

  const values = [
    {
      title: 'Accessibility',
      description: 'Making college guidance available to everyone, regardless of background or circumstances.',
      icon: <Heart className="h-8 w-8 text-red-500" />
    },
    {
      title: 'Empowerment',
      description: 'Providing students with the knowledge and tools they need to succeed.',
      icon: <TrendingUp className="h-8 w-8 text-blue-500" />
    },
    {
      title: 'Inclusivity',
      description: 'Celebrating diversity and ensuring our platform serves students from all communities.',
      icon: <Users className="h-8 w-8 text-green-500" />
    },
    {
      title: 'Excellence',
      description: 'Maintaining the highest standards in our content, technology, and student support.',
      icon: <Star className="h-8 w-8 text-yellow-500" />
    }
  ];

  const awards = [
    {
      title: 'EdTech Innovation Award 2024',
      organization: 'National Education Technology Association',
      description: 'Recognized for innovative approach to college access and financial aid guidance.'
    },
    {
      title: 'Social Impact Recognition',
      organization: 'College Access Foundation',
      description: 'Honored for significant contribution to expanding college opportunities for underserved students.'
    },
    {
      title: 'Best Student Resource Platform',
      organization: 'Higher Education Technology Summit',
      description: 'Selected as the top platform for comprehensive college planning and financial aid support.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">About Global Pathways</h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            We're on a mission to democratize college access by providing comprehensive, multilingual guidance 
            to students worldwide. Every student deserves the opportunity to pursue higher education, 
            regardless of their background or circumstances.
          </p>
        </div>

        {/* Mission & Vision */}
        <section className="mb-16">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="border-l-4 border-l-blue-600">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-6 w-6 mr-3 text-blue-600" />
                  Our Mission
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  To empower international and underprivileged students with comprehensive, accessible, 
                  and culturally sensitive college admissions guidance, financial aid resources, and 
                  ongoing support throughout their educational journey.
                </p>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-l-purple-600">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-6 w-6 mr-3 text-purple-600" />
                  Our Vision
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  A world where every student, regardless of their geographic location, economic status, 
                  or cultural background, has equal access to quality higher education and the resources 
                  needed to achieve their academic dreams.
                </p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Our Values */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-lg text-gray-600">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-8">
                  <div className="mb-4">
                    {value.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">
                    {value.title}
                  </h3>
                  <p className="text-gray-600 text-sm">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Our Story Timeline */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Journey</h2>
            <p className="text-lg text-gray-600">
              Key milestones in our mission to expand college access
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-blue-200"></div>
            
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="flex items-center mb-3">
                          <div className={`p-2 bg-blue-100 rounded-full mr-3 ${index % 2 !== 0 ? 'order-2 ml-3 mr-0' : ''}`}>
                            {milestone.icon}
                          </div>
                          <Badge variant="outline">{milestone.year}</Badge>
                        </div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">
                          {milestone.title}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          {milestone.description}
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="relative z-10">
                    <div className="w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow"></div>
                  </div>
                  
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Team */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-lg text-gray-600">
              Passionate individuals dedicated to expanding college access
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Users className="h-12 w-12 text-white" />
                  </div>
                  
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {member.name}
                  </h3>
                  <p className="text-blue-600 font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="text-gray-600 text-sm mb-4">
                    {member.bio}
                  </p>
                  
                  <div className="flex flex-wrap gap-1 justify-center">
                    {member.skills.map((skill, skillIndex) => (
                      <Badge key={skillIndex} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Awards & Recognition */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Awards & Recognition</h2>
            <p className="text-lg text-gray-600">
              Recognition for our impact in expanding college access
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {awards.map((award, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-8">
                  <div className="w-16 h-16 bg-yellow-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Award className="h-8 w-8 text-yellow-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {award.title}
                  </h3>
                  <p className="text-blue-600 font-medium mb-3">
                    {award.organization}
                  </p>
                  <p className="text-gray-600 text-sm">
                    {award.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Organizational Structure */}
        <section className="mb-16">
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
            <CardContent className="pt-8 pb-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Organizational Structure</h2>
                <p className="text-lg text-gray-600">
                  Building a sustainable organization for lasting impact
                </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Users className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Core Team</h3>
                  <p className="text-gray-600 text-sm">
                    Full-time staff managing platform development, content creation, and partnerships
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Star className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Advisory Board</h3>
                  <p className="text-gray-600 text-sm">
                    Experienced educators and financial aid professionals providing strategic guidance
                  </p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Heart className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Volunteers</h3>
                  <p className="text-gray-600 text-sm">
                    Student ambassadors and community volunteers supporting outreach efforts
                  </p>
                </div>
              </div>

              <div className="text-center mt-8">
                <Badge variant="secondary" className="text-sm">
                  501(c)(3) Nonprofit Status: Application in Progress
                </Badge>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Contact & Get Involved */}
        <section className="text-center bg-blue-600 text-white rounded-lg p-12">
          <h2 className="text-3xl font-bold mb-4">Get Involved</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Join our mission to expand college access. Whether you're an educator, volunteer, or supporter, 
            there are many ways to make a difference.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-blue-600 hover:bg-blue-50">
              <Mail className="h-4 w-4 mr-2" />
              Contact Us
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Users className="h-4 w-4 mr-2" />
              Volunteer
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Heart className="h-4 w-4 mr-2" />
              Donate
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
};