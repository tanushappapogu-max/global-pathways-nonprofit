import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { 
  Calculator, 
  DollarSign, 
  GraduationCap, 
  MapPin, 
  TrendingUp, 
  PieChart,
  BookOpen,
  Home,
  Car,
  ShoppingBag,
  Award,
  Users,
  Target,
  AlertCircle,
  CheckCircle,
  Info
} from 'lucide-react';

interface College {
  id: string;
  name: string;
  location: string;
  state: string;
  college_type: string;
  tuition_in_state: number;
  tuition_out_state: number;
  total_cost: number;
  meets_full_need: boolean;
  average_aid_amount: number;
}

interface CostBreakdown {
  tuition: number;
  fees: number;
  housing: number;
  meals: number;
  books: number;
  transportation: number;
  personal: number;
  total: number;
}

interface FinancialAid {
  grants: number;
  scholarships: number;
  workStudy: number;
  loans: number;
  total: number;
}

interface UserProfile {
  gpa: number;
  sat: number;
  act: number;
  state: string;
  familyIncome: number;
  isFirstGeneration: boolean;
  isLowIncome: boolean;
  isInternational: boolean;
  isMinority: boolean;
  major: string;
}

export const CostCalculatorPage: React.FC = () => {
  const [colleges, setColleges] = useState<College[]>([]);
  const [selectedCollege, setSelectedCollege] = useState<College | null>(null);
  const [collegeSearch, setCollegeSearch] = useState<string>('');
  const [filteredColleges, setFilteredColleges] = useState<College[]>([]);
  const [showResults, setShowResults] = useState(false);
  
  const [userProfile, setUserProfile] = useState<UserProfile>({
    gpa: 0,
    sat: 0,
    act: 0,
    state: '',
    familyIncome: 0,
    isFirstGeneration: false,
    isLowIncome: false,
    isInternational: false,
    isMinority: false,
    major: ''
  });

  const [residencyStatus, setResidencyStatus] = useState<string>('');

  useEffect(() => {
    loadColleges();
  }, []);

  useEffect(() => {
    if (collegeSearch) {
      const filtered = colleges.filter(college =>
        college.name.toLowerCase().includes(collegeSearch.toLowerCase()) ||
        college.location.toLowerCase().includes(collegeSearch.toLowerCase())
      );
      setFilteredColleges(filtered.slice(0, 10));
    } else {
      setFilteredColleges([]);
    }
  }, [collegeSearch, colleges]);

  const loadColleges = async () => {
    try {
      const { data, error } = await supabase
        .from('colleges_database_2025_10_06_01_15')
        .select('*')
        .order('name');

      if (data && !error) {
        setColleges(data);
      }
    } catch (error) {
      console.error('Error loading colleges:', error);
    }
  };

  const calculatePersonalizedCosts = (college: College | null): CostBreakdown => {
    if (!college) {
      // Default estimates based on college type
      return {
        tuition: 35000,
        fees: 2500,
        housing: 12000,
        meals: 5500,
        books: 1200,
        transportation: 1500,
        personal: 2500,
        total: 60200
      };
    }

    // Determine tuition based on residency and user profile
    let baseTuition = 0;
    if (userProfile.isInternational) {
      baseTuition = (college.tuition_out_state || college.tuition_in_state || 35000) * 1.2;
    } else if (userProfile.state === college.state || residencyStatus === 'in-state') {
      baseTuition = college.tuition_in_state || 25000;
    } else {
      baseTuition = college.tuition_out_state || college.tuition_in_state || 35000;
    }

    // Major-specific cost adjustments
    let majorMultiplier = 1.0;
    const stemMajors = ['engineering', 'computer science', 'biology', 'chemistry', 'physics', 'mathematics'];
    const businessMajors = ['business', 'finance', 'accounting', 'marketing', 'economics'];
    const artsMajors = ['art', 'music', 'theater', 'film', 'design'];

    if (stemMajors.some(major => userProfile.major.toLowerCase().includes(major))) {
      majorMultiplier = 1.15;
    } else if (businessMajors.some(major => userProfile.major.toLowerCase().includes(major))) {
      majorMultiplier = 1.1;
    } else if (artsMajors.some(major => userProfile.major.toLowerCase().includes(major))) {
      majorMultiplier = 1.2;
    }

    const adjustedTuition = baseTuition * majorMultiplier;

    // Location-based cost adjustments
    const locationMultiplier = college.location?.toLowerCase().includes('new york') || 
                              college.location?.toLowerCase().includes('california') || 
                              college.location?.toLowerCase().includes('boston') ? 1.3 : 1.0;

    const costs: CostBreakdown = {
      tuition: Math.round(adjustedTuition),
      fees: Math.round(2500 * locationMultiplier),
      housing: Math.round(12000 * locationMultiplier),
      meals: Math.round(5500 * locationMultiplier),
      books: Math.round(1200 * majorMultiplier),
      transportation: Math.round(userProfile.state === college.state ? 1000 : 2000),
      personal: Math.round(2500 * locationMultiplier),
      total: 0
    };

    costs.total = costs.tuition + costs.fees + costs.housing + costs.meals + costs.books + costs.transportation + costs.personal;
    return costs;
  };

  const calculatePersonalizedAid = (college: College | null): FinancialAid => {
    let estimatedAid: FinancialAid = {
      grants: 0,
      scholarships: 0,
      workStudy: 0,
      loans: 0,
      total: 0
    };

    const familyIncome = userProfile.familyIncome || 0;

    // Federal Pell Grant estimation
    if (familyIncome < 30000) {
      estimatedAid.grants += 7000;
    } else if (familyIncome < 50000) {
      estimatedAid.grants += 5000;
    } else if (familyIncome < 75000) {
      estimatedAid.grants += 2000;
    }

    // State grants
    if (college && userProfile.state === college.state && familyIncome < 60000) {
      estimatedAid.grants += 3000;
    }

    // Institutional aid
    if (college?.meets_full_need && familyIncome < 100000) {
      const totalCost = college.total_cost || 50000;
      const needBasedAid = Math.max(0, totalCost - (familyIncome * 0.1));
      estimatedAid.grants += Math.min(needBasedAid * 0.6, 25000);
    } else if (college?.average_aid_amount) {
      const aidMultiplier = familyIncome < 50000 ? 1.2 : familyIncome < 100000 ? 1.0 : 0.7;
      estimatedAid.grants += (college.average_aid_amount * aidMultiplier * 0.5);
    }

    // Merit scholarships based on academic profile
    if (userProfile.gpa >= 3.8 && (userProfile.sat >= 1400 || userProfile.act >= 32)) {
      estimatedAid.scholarships += 8000;
    } else if (userProfile.gpa >= 3.5 && (userProfile.sat >= 1200 || userProfile.act >= 27)) {
      estimatedAid.scholarships += 4000;
    } else if (userProfile.gpa >= 3.0) {
      estimatedAid.scholarships += 1500;
    }

    // Special population scholarships
    if (userProfile.isFirstGeneration) estimatedAid.scholarships += 2000;
    if (userProfile.isMinority) estimatedAid.scholarships += 1500;
    if (userProfile.isLowIncome) estimatedAid.grants += 2500;

    // Work-study
    if (familyIncome < 80000) {
      estimatedAid.workStudy = 2500;
    }

    // Federal student loans
    estimatedAid.loans = 5500;

    estimatedAid.total = estimatedAid.grants + estimatedAid.scholarships + estimatedAid.workStudy + estimatedAid.loans;
    return estimatedAid;
  };

  const handleCalculate = () => {
    setShowResults(true);
  };

  const handleCollegeSelect = (college: College) => {
    setSelectedCollege(college);
    setCollegeSearch(college.name);
    setFilteredColleges([]);
  };

  const costs = calculatePersonalizedCosts(selectedCollege);
  const aid = calculatePersonalizedAid(selectedCollege);
  const netCost = Math.max(0, costs.total - aid.total);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Calculator className="h-12 w-12 text-green-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">Personalized College Cost Calculator</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get accurate cost estimates based on your academic profile, location, and financial situation
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Input Section */}
          <div className="lg:col-span-2 space-y-6">
            {/* College Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <GraduationCap className="h-5 w-5 mr-2" />
                  Select College
                </CardTitle>
                <CardDescription>
                  Choose a specific college or use general estimates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search for a college..."
                    value={collegeSearch}
                    onChange={(e) => setCollegeSearch(e.target.value)}
                    className="w-full"
                  />
                  
                  {filteredColleges.length > 0 && (
                    <div className="absolute z-10 w-full mt-1 bg-white border border-gray-200 rounded-md shadow-lg max-h-60 overflow-y-auto">
                      {filteredColleges.map((college) => (
                        <div
                          key={college.id}
                          className="p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                          onClick={() => handleCollegeSelect(college)}
                        >
                          <div className="font-medium text-gray-900">{college.name}</div>
                          <div className="text-sm text-gray-600">{college.location}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {selectedCollege && (
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900">{selectedCollege.name}</h4>
                    <p className="text-blue-700">{selectedCollege.location}</p>
                    <div className="flex items-center mt-2 space-x-4">
                      <Badge className="bg-blue-100 text-blue-800">
                        {selectedCollege.college_type.replace('_', ' ').toUpperCase()}
                      </Badge>
                      {selectedCollege.meets_full_need && (
                        <Badge className="bg-green-100 text-green-800">
                          Meets Full Need
                        </Badge>
                      )}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* User Profile */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Your Profile
                </CardTitle>
                <CardDescription>
                  Tell us about yourself for personalized estimates
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Academic Information */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Academic Information</h4>
                    
                    <div>
                      <Label htmlFor="gpa">GPA (4.0 scale)</Label>
                      <Input
                        id="gpa"
                        type="number"
                        step="0.01"
                        min="0"
                        max="4.0"
                        value={userProfile.gpa || ''}
                        onChange={(e) => setUserProfile({...userProfile, gpa: parseFloat(e.target.value) || 0})}
                        placeholder="3.75"
                      />
                    </div>

                    <div>
                      <Label htmlFor="sat">SAT Score</Label>
                      <Input
                        id="sat"
                        type="number"
                        min="400"
                        max="1600"
                        value={userProfile.sat || ''}
                        onChange={(e) => setUserProfile({...userProfile, sat: parseInt(e.target.value) || 0})}
                        placeholder="1450"
                      />
                    </div>

                    <div>
                      <Label htmlFor="act">ACT Score</Label>
                      <Input
                        id="act"
                        type="number"
                        min="1"
                        max="36"
                        value={userProfile.act || ''}
                        onChange={(e) => setUserProfile({...userProfile, act: parseInt(e.target.value) || 0})}
                        placeholder="32"
                      />
                    </div>

                    <div>
                      <Label htmlFor="major">Intended Major</Label>
                      <Input
                        id="major"
                        value={userProfile.major}
                        onChange={(e) => setUserProfile({...userProfile, major: e.target.value})}
                        placeholder="Computer Science, Biology, etc."
                      />
                    </div>
                  </div>

                  {/* Personal Information */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-gray-900">Personal Information</h4>

                    <div>
                      <Label htmlFor="state">Home State</Label>
                      <Select value={userProfile.state} onValueChange={(value) => setUserProfile({...userProfile, state: value})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your state" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="CA">California</SelectItem>
                          <SelectItem value="NY">New York</SelectItem>
                          <SelectItem value="TX">Texas</SelectItem>
                          <SelectItem value="FL">Florida</SelectItem>
                          <SelectItem value="PA">Pennsylvania</SelectItem>
                          <SelectItem value="IL">Illinois</SelectItem>
                          <SelectItem value="OH">Ohio</SelectItem>
                          <SelectItem value="international">International</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="residency">Residency Status</Label>
                      <Select value={residencyStatus} onValueChange={setResidencyStatus}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select residency status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="in-state">In-State</SelectItem>
                          <SelectItem value="out-of-state">Out-of-State</SelectItem>
                          <SelectItem value="international">International</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="income">Family Income (Annual)</Label>
                      <Select value={userProfile.familyIncome?.toString() || ''} onValueChange={(value) => setUserProfile({...userProfile, familyIncome: parseInt(value) || 0})}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select income range" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0">Under $30,000</SelectItem>
                          <SelectItem value="30000">$30,000 - $50,000</SelectItem>
                          <SelectItem value="50000">$50,000 - $75,000</SelectItem>
                          <SelectItem value="75000">$75,000 - $100,000</SelectItem>
                          <SelectItem value="100000">$100,000 - $150,000</SelectItem>
                          <SelectItem value="150000">Over $150,000</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="firstGen"
                          checked={userProfile.isFirstGeneration}
                          onCheckedChange={(checked) => setUserProfile({...userProfile, isFirstGeneration: !!checked})}
                        />
                        <Label htmlFor="firstGen" className="text-sm">First-generation college student</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="lowIncome"
                          checked={userProfile.isLowIncome}
                          onCheckedChange={(checked) => setUserProfile({...userProfile, isLowIncome: !!checked})}
                        />
                        <Label htmlFor="lowIncome" className="text-sm">Low-income background</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="international"
                          checked={userProfile.isInternational}
                          onCheckedChange={(checked) => setUserProfile({...userProfile, isInternational: !!checked})}
                        />
                        <Label htmlFor="international" className="text-sm">International student</Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="minority"
                          checked={userProfile.isMinority}
                          onCheckedChange={(checked) => setUserProfile({...userProfile, isMinority: !!checked})}
                        />
                        <Label htmlFor="minority" className="text-sm">Underrepresented minority</Label>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex justify-center">
                  <Button 
                    onClick={handleCalculate}
                    size="lg"
                    className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-3"
                  >
                    <Calculator className="h-5 w-5 mr-2" />
                    Calculate My Costs
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Results Section */}
          <div className="lg:col-span-1">
            {showResults && (
              <div className="space-y-6">
                {/* Cost Breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <DollarSign className="h-5 w-5 mr-2" />
                      Annual Cost Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Tuition & Fees</span>
                        <span className="font-semibold">{formatCurrency(costs.tuition + costs.fees)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Housing & Meals</span>
                        <span className="font-semibold">{formatCurrency(costs.housing + costs.meals)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Books & Supplies</span>
                        <span className="font-semibold">{formatCurrency(costs.books)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Transportation</span>
                        <span className="font-semibold">{formatCurrency(costs.transportation)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Personal Expenses</span>
                        <span className="font-semibold">{formatCurrency(costs.personal)}</span>
                      </div>
                      <div className="border-t pt-3 flex justify-between text-lg font-bold">
                        <span>Total Annual Cost</span>
                        <span className="text-red-600">{formatCurrency(costs.total)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Financial Aid */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Award className="h-5 w-5 mr-2" />
                      Estimated Financial Aid
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Grants</span>
                        <span className="font-semibold text-green-600">{formatCurrency(aid.grants)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Scholarships</span>
                        <span className="font-semibold text-green-600">{formatCurrency(aid.scholarships)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Work-Study</span>
                        <span className="font-semibold text-blue-600">{formatCurrency(aid.workStudy)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Student Loans</span>
                        <span className="font-semibold text-orange-600">{formatCurrency(aid.loans)}</span>
                      </div>
                      <div className="border-t pt-3 flex justify-between text-lg font-bold">
                        <span>Total Aid</span>
                        <span className="text-green-600">{formatCurrency(aid.total)}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Net Cost */}
                <Card className="bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Net Annual Cost</h3>
                      <div className="text-3xl font-bold text-blue-600 mb-2">
                        {formatCurrency(netCost)}
                      </div>
                      <p className="text-sm text-gray-600">
                        After estimated financial aid
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* 4-Year Total */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <TrendingUp className="h-5 w-5 mr-2" />
                      4-Year Projection
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Total 4-Year Cost</span>
                        <span className="font-semibold">{formatCurrency(costs.total * 4 * 1.06)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Total 4-Year Aid</span>
                        <span className="font-semibold text-green-600">{formatCurrency(aid.total * 4)}</span>
                      </div>
                      <div className="border-t pt-2 flex justify-between text-lg font-bold">
                        <span>Net 4-Year Cost</span>
                        <span className="text-blue-600">{formatCurrency((costs.total * 4 * 1.06) - (aid.total * 4))}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        *Includes 3% annual inflation on costs
                      </p>
                    </div>
                  </CardContent>
                </Card>

                {/* Action Buttons */}
                <div className="space-y-3">
                  <Button asChild className="w-full">
                    <Link to="/auto-scholarships">
                      <Award className="h-4 w-4 mr-2" />
                      Find Scholarships
                    </Link>
                  </Button>
                  
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/college-comparison">
                      <PieChart className="h-4 w-4 mr-2" />
                      Compare Colleges
                    </Link>
                  </Button>
                </div>
              </div>
            )}

            {!showResults && (
              <Card>
                <CardContent className="text-center py-12">
                  <Calculator className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Ready to Calculate?</h3>
                  <p className="text-gray-600 mb-4">
                    Fill out your profile information and click "Calculate My Costs" to see personalized estimates.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};