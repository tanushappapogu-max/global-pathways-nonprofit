import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Search, 
  DollarSign, 
  Calendar,
  MapPin,
  GraduationCap,
  Users,
  Star,
  ExternalLink,
  Filter,
  Sparkles,
  TrendingUp,
  Award,
  CheckCircle,
  Bookmark,
  BookmarkCheck,
  Brain,
  Zap,
  Clock,
  AlertCircle,
  Heart,
  Target,
  Lightbulb,
  Trophy,
  Bell,
  Save
} from 'lucide-react';

interface Scholarship {
  id: string;
  source: string;
  source_id?: string;
  name: string;
  amount?: string;
  eligibility?: string;
  deadline?: string;
  link?: string;
  region?: string;
  category?: string;
  raw_json?: any;
  last_checked?: string;
  last_updated?: string;
  expired?: boolean;
  link_broken?: boolean;
  needs_review?: boolean;
  created_at?: string;
  match_score?: number;
  match_reasons?: string[];
  priority_level?: string;
  ai_recommended?: boolean;
}

interface StudentProfile {
  state: string;
  gpa: number;
  sat: number;
  act: number;
  isFirstGeneration: boolean;
  isLowIncome: boolean;
  isInternational: boolean;
  isMinority: boolean;
  isWomen: boolean;
  intendedMajor: string;
  familyIncome: number;
  additionalInfo: string;
}

export const AutoScholarshipFinderPage: React.FC = () => {
  const { user } = useAuth();
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [matchedScholarships, setMatchedScholarships] = useState<Scholarship[]>([]);
  const [bookmarkedScholarships, setBookmarkedScholarships] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [useAI, setUseAI] = useState(true);
  const [progress, setProgress] = useState(0);
  
  const [studentProfile, setStudentProfile] = useState<StudentProfile>({
    state: '',
    gpa: 0,
    sat: 0,
    act: 0,
    isFirstGeneration: false,
    isLowIncome: false,
    isInternational: false,
    isMinority: false,
    isWomen: false,
    intendedMajor: '',
    familyIncome: 0,
    additionalInfo: ''
  });

  const [filters, setFilters] = useState({
    minAmount: 0,
    maxAmount: 100000,
    renewable: false,
    deadlineWithin: 'all' as 'all' | '30days' | '60days' | '90days'
  });

  useEffect(() => {
    loadScholarships();
    if (user) {
      loadBookmarkedScholarships();
    }

    // Set up real-time subscription for scholarship updates
    const channel = supabase
      .channel('scholarships-changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'scholarships' }, 
        (payload) => {
          console.log('Scholarship update received:', payload);
          loadScholarships(); // Reload scholarships when changes occur
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);
  const loadScholarships = async () => {
    try {
      const { data, error } = await supabase
        .from('scholarships')
        .select('*')
        .eq('expired', false)
        .eq('needs_review', false);

      if (data && !error) {
        setScholarships(data);
      }
    } catch (error) {
      console.error('Error loading scholarships:', error);
    }
  };

  const loadBookmarkedScholarships = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('scholarship_bookmarks_2025_10_07_02_17')
        .select('scholarship_id')
        .eq('user_id', user.id);
      
      if (data && !error) {
        setBookmarkedScholarships(new Set(data.map(item => item.scholarship_id)));
      }
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    }
  };

  const handleFindScholarships = async () => {
    setLoading(true);
    setProgress(0);
    
    try {
      if (useAI && scholarships.length > 0) {
        setAiLoading(true);
        setProgress(25);
        
        const { data: aiResponse, error: aiError } = await supabase.functions.invoke(
          'gpt_scholarship_recommender_fixed_2025_10_07_02_17',
          {
            body: {
              studentProfile,
              scholarships: scholarships.slice(0, 50)
            }
          }
        );
        
        setProgress(75);
        
        if (aiResponse?.success && aiResponse.recommendations) {
          const enhancedRecommendations = aiResponse.recommendations.map((rec: any) => {
            const originalScholarship = scholarships.find(s => s.id === rec.id);
            return {
              ...originalScholarship,
              ...rec,
              ai_recommended: true
            };
          }).filter(Boolean);
          
          setMatchedScholarships(enhancedRecommendations);
          setProgress(100);
        } else {
          await handleRegularMatching();
        }
        
        setAiLoading(false);
      } else {
        await handleRegularMatching();
      }
      
      setShowResults(true);
    } catch (error) {
      console.error('Error finding scholarships:', error);
      await handleRegularMatching();
    } finally {
      setLoading(false);
      setAiLoading(false);
      setProgress(100);
    }
  };

  const handleRegularMatching = async () => {
    setProgress(25);
    
    const { data, error } = await supabase.rpc('find_matching_scholarships_2025_10_07_01_55', {
      student_state: studentProfile.state || null,
      student_gpa: studentProfile.gpa || null,
      student_sat: studentProfile.sat || null,
      student_act: studentProfile.act || null,
      is_first_generation: studentProfile.isFirstGeneration,
      is_low_income: studentProfile.isLowIncome,
      is_international: studentProfile.isInternational,
      is_minority: studentProfile.isMinority,
      is_women: studentProfile.isWomen,
      intended_major: studentProfile.intendedMajor || null,
      family_income: studentProfile.familyIncome || null
    });

    setProgress(75);

    if (data && !error) {
      let filtered = data.filter((scholarship: any) => {
        if (filters.minAmount > 0 && (scholarship.amount_max || 0) < filters.minAmount) return false;
        if (filters.maxAmount < 100000 && (scholarship.amount_min || 0) > filters.maxAmount) return false;
        if (filters.renewable && !scholarship.renewable) return false;
        
        if (filters.deadlineWithin !== 'all' && scholarship.application_deadline) {
          const deadline = new Date(scholarship.application_deadline);
          const now = new Date();
          const daysUntilDeadline = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          
          const maxDays = filters.deadlineWithin === '30days' ? 30 : 
                         filters.deadlineWithin === '60days' ? 60 : 90;
          
          if (daysUntilDeadline > maxDays) return false;
        }
        
        return true;
      });

      setMatchedScholarships(filtered);
    }
    
    setProgress(100);
  };

  const handleBookmarkScholarship = async (scholarship: Scholarship) => {
    if (!user) return;
    
    try {
      const isBookmarked = bookmarkedScholarships.has(scholarship.id);
      
      if (isBookmarked) {
        await supabase
          .from('scholarship_bookmarks_2025_10_07_02_17')
          .delete()
          .eq('user_id', user.id)
          .eq('scholarship_id', scholarship.id);
        
        setBookmarkedScholarships(prev => {
          const newSet = new Set(prev);
          newSet.delete(scholarship.id);
          return newSet;
        });
      } else {
        await supabase
          .from('scholarship_bookmarks_2025_10_07_02_17')
          .insert({
            user_id: user.id,
            scholarship_id: scholarship.id,
            scholarship_name: scholarship.scholarship_name,
            provider_organization: scholarship.provider_organization,
            amount_min: scholarship.amount_min,
            amount_max: scholarship.amount_max,
            application_deadline: scholarship.application_deadline,
            website_url: scholarship.website_url,
            priority_level: scholarship.priority_level || 'medium'
          });
        
        setBookmarkedScholarships(prev => new Set([...prev, scholarship.id]));
      }
    } catch (error) {
      console.error('Error bookmarking scholarship:', error);
    }
  };
  const getAmountDisplay = (scholarship: Scholarship) => {
    if (!scholarship.amount) return 'See provider';
    return scholarship.amount;
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-50';
    if (score >= 60) return 'text-blue-600 bg-blue-50';
    if (score >= 40) return 'text-yellow-600 bg-yellow-50';
    return 'text-gray-600 bg-gray-50';
  };

  const getDeadlineStatus = (deadline?: string) => {
    if (!deadline) return { text: 'No deadline specified', color: 'text-gray-500' };
    
    const deadlineDate = new Date(deadline);
    const now = new Date();
    const daysUntil = Math.ceil((deadlineDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntil < 0) return { text: 'Deadline passed', color: 'text-red-500' };
    if (daysUntil <= 30) return { text: `${daysUntil} days left`, color: 'text-red-500' };
    if (daysUntil <= 60) return { text: `${daysUntil} days left`, color: 'text-yellow-500' };
    return { text: `${daysUntil} days left`, color: 'text-green-500' };
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Brain className="h-12 w-12 text-blue-600 mr-3" />
            <h1 className="text-4xl font-bold text-gray-900">AI-Powered Scholarship Finder</h1>
          </div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get personalized scholarship recommendations powered by advanced AI matching
          </p>
          <div className="flex items-center justify-center mt-4 space-x-4">
            <Badge className="bg-blue-100 text-blue-800 flex items-center">
              <Sparkles className="h-4 w-4 mr-1" />
              AI-Enhanced
            </Badge>
            <Badge className="bg-green-100 text-green-800 flex items-center">
              <Target className="h-4 w-4 mr-1" />
              Personalized Matching
            </Badge>
            <Badge className="bg-purple-100 text-purple-800 flex items-center">
              <Zap className="h-4 w-4 mr-1" />
              Real-time Updates
            </Badge>
          </div>
        </div>

        {/* Student Profile Form */}
        <Card className="mb-8 shadow-lg border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
            <CardTitle className="flex items-center text-xl">
              <Users className="h-6 w-6 mr-2" />
              Your Student Profile
            </CardTitle>
            <CardDescription className="text-blue-100">
              Tell us about yourself to get the most accurate scholarship matches
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Academic Information */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900 flex items-center">
                  <GraduationCap className="h-5 w-5 mr-2 text-blue-600" />
                  Academic Information
                </h3>
                
                <div>
                  <Label htmlFor="gpa">GPA (4.0 scale)</Label>
                  <Input
                    id="gpa"
                    type="number"
                    step="0.01"
                    min="0"
                    max="4.0"
                    value={studentProfile.gpa || ''}
                    onChange={(e) => setStudentProfile({...studentProfile, gpa: parseFloat(e.target.value) || 0})}
                    placeholder="3.75"
                  />
                </div>

                <div>
                  <Label htmlFor="sat">SAT Score</Label>
                  <Input
                    id="sat"
                    type="number"
                    min="400"
                    max="1600"
                    value={studentProfile.sat || ''}
                    onChange={(e) => setStudentProfile({...studentProfile, sat: parseInt(e.target.value) || 0})}
                    placeholder="1450"
                  />
                </div>

                <div>
                  <Label htmlFor="act">ACT Score</Label>
                  <Input
                    id="act"
                    type="number"
                    min="1"
                    max="36"
                    value={studentProfile.act || ''}
                    onChange={(e) => setStudentProfile({...studentProfile, act: parseInt(e.target.value) || 0})}
                    placeholder="32"
                  />
                </div>
              </div>

              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900 flex items-center">
                  <MapPin className="h-5 w-5 mr-2 text-green-600" />
                  Personal Information
                </h3>

                <div>
                  <Label htmlFor="state">State/Region</Label>
                  <Select value={studentProfile.state} onValueChange={(value) => setStudentProfile({...studentProfile, state: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your state" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AL">Alabama</SelectItem>
                      <SelectItem value="CA">California</SelectItem>
                      <SelectItem value="FL">Florida</SelectItem>
                      <SelectItem value="NY">New York</SelectItem>
                      <SelectItem value="TX">Texas</SelectItem>
                      <SelectItem value="PA">Pennsylvania</SelectItem>
                      <SelectItem value="international">International</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="major">Intended Major</Label>
                  <Input
                    id="major"
                    value={studentProfile.intendedMajor}
                    onChange={(e) => setStudentProfile({...studentProfile, intendedMajor: e.target.value})}
                    placeholder="Computer Science, Biology, etc."
                  />
                </div>

                <div>
                  <Label htmlFor="income">Family Income (Annual)</Label>
                  <Select value={studentProfile.familyIncome?.toString() || ''} onValueChange={(value) => setStudentProfile({...studentProfile, familyIncome: parseInt(value) || 0})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select income range" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="0">Under $30,000</SelectItem>
                      <SelectItem value="30000">$30,000 - $50,000</SelectItem>
                      <SelectItem value="50000">$50,000 - $75,000</SelectItem>
                      <SelectItem value="75000">$75,000 - $100,000</SelectItem>
                      <SelectItem value="100000">$100,000 - $150,000</SelectItem>
                      <SelectItem value="150000">Over $150,000</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Demographics & Characteristics */}
              <div className="space-y-4">
                <h3 className="font-semibold text-gray-900 flex items-center">
                  <Award className="h-5 w-5 mr-2 text-purple-600" />
                  Demographics & Characteristics
                </h3>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="firstGen"
                      checked={studentProfile.isFirstGeneration}
                      onCheckedChange={(checked) => setStudentProfile({...studentProfile, isFirstGeneration: !!checked})}
                    />
                    <Label htmlFor="firstGen" className="text-sm">First-generation college student</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="lowIncome"
                      checked={studentProfile.isLowIncome}
                      onCheckedChange={(checked) => setStudentProfile({...studentProfile, isLowIncome: !!checked})}
                    />
                    <Label htmlFor="lowIncome" className="text-sm">Low-income background</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="international"
                      checked={studentProfile.isInternational}
                      onCheckedChange={(checked) => setStudentProfile({...studentProfile, isInternational: !!checked})}
                    />
                    <Label htmlFor="international" className="text-sm">International student</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="minority"
                      checked={studentProfile.isMinority}
                      onCheckedChange={(checked) => setStudentProfile({...studentProfile, isMinority: !!checked})}
                    />
                    <Label htmlFor="minority" className="text-sm">Underrepresented minority</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="women"
                      checked={studentProfile.isWomen}
                      onCheckedChange={(checked) => setStudentProfile({...studentProfile, isWomen: !!checked})}
                    />
                    <Label htmlFor="women" className="text-sm">Women in STEM</Label>
                  </div>
                </div>

                <div>
                  <Label htmlFor="additionalInfo">Additional Information</Label>
                  <Textarea
                    id="additionalInfo"
                    value={studentProfile.additionalInfo}
                    onChange={(e) => setStudentProfile({...studentProfile, additionalInfo: e.target.value})}
                    placeholder="Any additional information about your background, achievements, or circumstances..."
                    rows={3}
                  />
                </div>
              </div>
            </div>

            {/* AI Toggle and Search Button */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
              <div className="flex items-center space-x-3">
                <Checkbox
                  id="useAI"
                  checked={useAI}
                  onCheckedChange={(checked) => setUseAI(!!checked)}
                />
                <Label htmlFor="useAI" className="flex items-center text-sm font-medium">
                  <Brain className="h-4 w-4 mr-2 text-blue-600" />
                  Use AI-Powered Recommendations (Recommended)
                </Label>
              </div>

              <Button 
                onClick={handleFindScholarships} 
                disabled={loading || aiLoading}
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3"
              >
                {loading || aiLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    {aiLoading ? 'AI Analyzing...' : 'Searching...'}
                  </>
                ) : (
                  <>
                    <Search className="h-5 w-5 mr-2" />
                    Find My Scholarships
                  </>
                )}
              </Button>
            </div>

            {/* Progress Bar */}
            {(loading || aiLoading) && (
              <div className="mt-4">
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>{aiLoading ? 'AI is analyzing your profile...' : 'Searching scholarships...'}</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="w-full" />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Section */}
        {showResults && (
          <div className="space-y-6">
            {/* Results Summary */}
            <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      Found {matchedScholarships.length} Matching Scholarships
                    </h3>
                    <p className="text-gray-600">
                      Total potential funding: ${matchedScholarships.reduce((sum, s) => sum + (s.amount_max || s.amount_min || 0), 0).toLocaleString()}
                    </p>
                  </div>
                  <Trophy className="h-12 w-12 text-yellow-500" />
                </div>
              </CardContent>
            </Card>

            {/* Scholarship Results */}
            <div className="grid gap-6">
              {matchedScholarships.map((scholarship) => {
                const deadlineStatus = getDeadlineStatus(scholarship.deadline);
                const isBookmarked = bookmarkedScholarships.has(scholarship.id);
                
                return (
                  <Card key={scholarship.id} className="hover:shadow-lg transition-shadow border-l-4 border-l-blue-500">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center mb-2">
                            <h3 className="text-xl font-bold text-gray-900 mr-3">
                              {scholarship.name}
                            </h3>
                            {scholarship.ai_recommended && (
                              <Badge className="bg-purple-100 text-purple-800 flex items-center">
                                <Brain className="h-3 w-3 mr-1" />
                                AI Match
                              </Badge>
                            )}
                            {scholarship.match_score && (
                              <Badge className={`ml-2 ${getMatchScoreColor(scholarship.match_score)}`}>
                                {scholarship.match_score}% Match
                              </Badge>
                            )}
                          </div>
                          <p className="text-gray-600 mb-2">{scholarship.source}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span className="flex items-center">
                              <DollarSign className="h-4 w-4 mr-1" />
                              {getAmountDisplay(scholarship)}
                            </span>
                            <span className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              <span className={deadlineStatus.color}>
                                {deadlineStatus.text}
                              </span>
                            </span>
                            {scholarship.category && (
                              <Badge variant="outline" className="text-green-600">
                                {scholarship.category}
                              </Badge>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {user && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleBookmarkScholarship(scholarship)}
                              className={isBookmarked ? 'text-red-600' : 'text-gray-400'}
                            >
                              {isBookmarked ? <BookmarkCheck className="h-5 w-5" /> : <Bookmark className="h-5 w-5" />}
                            </Button>
                          )}
                          {scholarship.link && (
                            <Button asChild>
                              <a
                                href={scholarship.link}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center"
                              >
                                Apply Now
                                <ExternalLink className="h-4 w-4 ml-2" />
                              </a>
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* AI Match Reasons */}
                      {scholarship.match_reasons && scholarship.match_reasons.length > 0 && (
                        <div className="mb-4">
                          <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                            <Lightbulb className="h-4 w-4 mr-2 text-yellow-500" />
                            Why this matches you:
                          </h4>
                          <div className="flex flex-wrap gap-2">
                            {scholarship.match_reasons.map((reason, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {reason}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Eligibility and Region */}
                      {(scholarship.eligibility || scholarship.region) && (
                        <div className="mt-4">
                          {scholarship.eligibility && (
                            <p className="text-sm text-gray-600 mb-2">
                              <strong>Eligibility:</strong> {scholarship.eligibility}
                            </p>
                          )}
                          {scholarship.region && (
                            <p className="text-sm text-gray-600">
                              <strong>Region:</strong> {scholarship.region}
                            </p>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {matchedScholarships.length === 0 && (
              <Card>
                <CardContent className="text-center py-12">
                  <Search className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No Scholarships Found</h3>
                  <p className="text-gray-600 mb-4">
                    Try adjusting your profile information or search criteria.
                  </p>
                  <Button onClick={() => setShowResults(false)} variant="outline">
                    Modify Search
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
};