import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Edit, 
  Trash2, 
  RefreshCw,
  BarChart3,
  Clock,
  ExternalLink
} from 'lucide-react';

interface Scholarship {
  id: string;
  source: string;
  source_id?: string;
  name: string;
  amount?: string;
  eligibility?: string;
  deadline?: string;
  link?: string;
  region?: string;
  category?: string;
  expired?: boolean;
  link_broken?: boolean;
  needs_review?: boolean;
  created_at?: string;
  last_checked?: string;
}

interface Report {
  id: string;
  scholarship_id: string;
  issue: string;
  created_at: string;
  scholarship?: Scholarship;
}

interface IngestReport {
  id: string;
  source: string;
  status: string;
  message?: string;
  items_processed: number;
  items_added: number;
  items_updated: number;
  items_flagged: number;
  error?: string;
  occurred_at: string;
}

export const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [scholarships, setScholarships] = useState<Scholarship[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [ingestReports, setIngestReports] = useState<IngestReport[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingScholarship, setEditingScholarship] = useState<Scholarship | null>(null);
  const [activeTab, setActiveTab] = useState<'review' | 'reports' | 'ingestion' | 'stats'>('review');

  // Check if user is admin (you can implement your own admin check logic)
  const isAdmin = user?.email?.includes('admin') || user?.user_metadata?.role === 'admin';

  useEffect(() => {
    if (isAdmin) {
      loadData();
    }
  }, [isAdmin]);

  const loadData = async () => {
    setLoading(true);
    try {
      await Promise.all([
        loadScholarshipsForReview(),
        loadReports(),
        loadIngestReports()
      ]);
    } catch (error) {
      console.error('Error loading admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadScholarshipsForReview = async () => {
    const { data, error } = await supabase
      .from('scholarships')
      .select('*')
      .eq('needs_review', true)
      .order('created_at', { ascending: false });

    if (data && !error) {
      setScholarships(data);
    }
  };

  const loadReports = async () => {
    const { data, error } = await supabase
      .from('reports')
      .select(`
        *,
        scholarship:scholarships(*)
      `)
      .order('created_at', { ascending: false })
      .limit(50);

    if (data && !error) {
      setReports(data);
    }
  };

  const loadIngestReports = async () => {
    const { data, error } = await supabase
      .from('ingest_reports')
      .select('*')
      .order('occurred_at', { ascending: false })
      .limit(100);

    if (data && !error) {
      setIngestReports(data);
    }
  };

  const approveScholarship = async (id: string) => {
    const { error } = await supabase
      .from('scholarships')
      .update({ needs_review: false })
      .eq('id', id);

    if (!error) {
      setScholarships(scholarships.filter(s => s.id !== id));
    }
  };

  const deleteScholarship = async (id: string) => {
    if (confirm('Are you sure you want to delete this scholarship?')) {
      const { error } = await supabase
        .from('scholarships')
        .delete()
        .eq('id', id);

      if (!error) {
        setScholarships(scholarships.filter(s => s.id !== id));
      }
    }
  };

  const updateScholarship = async (scholarship: Scholarship) => {
    const { error } = await supabase
      .from('scholarships')
      .update({
        name: scholarship.name,
        amount: scholarship.amount,
        eligibility: scholarship.eligibility,
        deadline: scholarship.deadline,
        link: scholarship.link,
        region: scholarship.region,
        category: scholarship.category,
        needs_review: false
      })
      .eq('id', scholarship.id);

    if (!error) {
      setScholarships(scholarships.filter(s => s.id !== scholarship.id));
      setEditingScholarship(null);
    }
  };

  const resolveReport = async (reportId: string) => {
    const { error } = await supabase
      .from('reports')
      .delete()
      .eq('id', reportId);

    if (!error) {
      setReports(reports.filter(r => r.id !== reportId));
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card>
            <CardContent className="text-center py-12">
              <Shield className="h-16 w-16 text-red-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h3>
              <p className="text-gray-600">You don't have permission to access the admin panel.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <RefreshCw className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
            <p className="text-gray-600">Loading admin data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Admin Panel</h1>
          <p className="text-xl text-gray-600">Manage scholarships and monitor ingestion</p>
        </div>

        {/* Tabs */}
        <div className="mb-8">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {[
                { id: 'review', label: 'Review Queue', count: scholarships.length },
                { id: 'reports', label: 'User Reports', count: reports.length },
                { id: 'ingestion', label: 'Ingestion Logs', count: ingestReports.length },
                { id: 'stats', label: 'Statistics', count: 0 }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                  {tab.count > 0 && (
                    <Badge className="ml-2 bg-red-100 text-red-800">
                      {tab.count}
                    </Badge>
                  )}
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Review Queue Tab */}
        {activeTab === 'review' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Scholarships Pending Review</CardTitle>
                <CardDescription>
                  Review and approve scholarships that need manual verification
                </CardDescription>
              </CardHeader>
            </Card>

            {scholarships.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">All Clear!</h3>
                  <p className="text-gray-600">No scholarships pending review.</p>
                </CardContent>
              </Card>
            ) : (
              scholarships.map((scholarship) => (
                <Card key={scholarship.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2">
                          {scholarship.name}
                        </h3>
                        <p className="text-gray-600 mb-2">Source: {scholarship.source}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>Amount: {scholarship.amount || 'Not specified'}</span>
                          <span>Deadline: {scholarship.deadline || 'Not specified'}</span>
                          <span>Region: {scholarship.region || 'Not specified'}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setEditingScholarship(scholarship)}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => approveScholarship(scholarship.id)}
                          className="text-green-600 hover:text-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteScholarship(scholarship.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete
                        </Button>
                      </div>
                    </div>

                    {scholarship.eligibility && (
                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium text-gray-900 mb-2">Eligibility</h4>
                        <p className="text-sm text-gray-600">{scholarship.eligibility}</p>
                      </div>
                    )}

                    {scholarship.link && (
                      <div className="mt-4">
                        <a
                          href={scholarship.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 flex items-center"
                        >
                          View Application Link
                          <ExternalLink className="h-4 w-4 ml-1" />
                        </a>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}

        {/* User Reports Tab */}
        {activeTab === 'reports' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Reports</CardTitle>
                <CardDescription>
                  Issues reported by users about scholarships
                </CardDescription>
              </CardHeader>
            </Card>

            {reports.map((report) => (
              <Card key={report.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">
                        Report: {report.issue}
                      </h3>
                      <p className="text-gray-600 mb-2">
                        Scholarship: {report.scholarship?.name || 'Unknown'}
                      </p>
                      <p className="text-sm text-gray-500">
                        Reported: {new Date(report.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => resolveReport(report.id)}
                      className="text-green-600 hover:text-green-700"
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Resolve
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Ingestion Logs Tab */}
        {activeTab === 'ingestion' && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Ingestion Reports</CardTitle>
                <CardDescription>
                  Monitor automated scholarship ingestion from various sources
                </CardDescription>
              </CardHeader>
            </Card>

            {ingestReports.map((report) => (
              <Card key={report.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 mr-3">
                          {report.source}
                        </h3>
                        <Badge className={
                          report.status === 'success' ? 'bg-green-100 text-green-800' :
                          report.status === 'error' ? 'bg-red-100 text-red-800' :
                          'bg-yellow-100 text-yellow-800'
                        }>
                          {report.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <span className="text-gray-500">Processed:</span>
                          <span className="ml-1 font-medium">{report.items_processed}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Added:</span>
                          <span className="ml-1 font-medium text-green-600">{report.items_added}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Updated:</span>
                          <span className="ml-1 font-medium text-blue-600">{report.items_updated}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Flagged:</span>
                          <span className="ml-1 font-medium text-yellow-600">{report.items_flagged}</span>
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-500 mt-2">
                        {new Date(report.occurred_at).toLocaleString()}
                      </p>
                      
                      {report.message && (
                        <p className="text-sm text-gray-600 mt-2">{report.message}</p>
                      )}
                      
                      {report.error && (
                        <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-700">
                          Error: {report.error}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Edit Modal */}
        {editingScholarship && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <CardHeader>
                <CardTitle>Edit Scholarship</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={editingScholarship.name}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      name: e.target.value
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="amount">Amount</Label>
                  <Input
                    id="amount"
                    value={editingScholarship.amount || ''}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      amount: e.target.value
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="deadline">Deadline</Label>
                  <Input
                    id="deadline"
                    type="date"
                    value={editingScholarship.deadline || ''}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      deadline: e.target.value
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="link">Application Link</Label>
                  <Input
                    id="link"
                    value={editingScholarship.link || ''}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      link: e.target.value
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="region">Region</Label>
                  <Input
                    id="region"
                    value={editingScholarship.region || ''}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      region: e.target.value
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={editingScholarship.category || ''}
                    onValueChange={(value) => setEditingScholarship({
                      ...editingScholarship,
                      category: value
                    })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="STEM">STEM</SelectItem>
                      <SelectItem value="Arts">Arts</SelectItem>
                      <SelectItem value="General">General</SelectItem>
                      <SelectItem value="Leadership">Leadership</SelectItem>
                      <SelectItem value="FirstGen">First Generation</SelectItem>
                      <SelectItem value="International">International</SelectItem>
                      <SelectItem value="LowIncome">Low Income</SelectItem>
                      <SelectItem value="Merit">Merit</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label htmlFor="eligibility">Eligibility</Label>
                  <Textarea
                    id="eligibility"
                    value={editingScholarship.eligibility || ''}
                    onChange={(e) => setEditingScholarship({
                      ...editingScholarship,
                      eligibility: e.target.value
                    })}
                    rows={4}
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button
                    variant="outline"
                    onClick={() => setEditingScholarship(null)}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => updateScholarship(editingScholarship)}
                  >
                    Save Changes
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};