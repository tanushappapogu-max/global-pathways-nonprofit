import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { 
  Users, 
  Plus, 
  Download, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Edit,
  Trash2,
  FileText,
  BarChart3
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

interface CounselorProfile {
  id: string;
  email?: string;
  full_name?: string;
  school_name?: string;
  school_district?: string;
  phone_number?: string;
  is_verified: boolean;
}

interface CounselorStudent {
  id: string;
  student_name: string;
  student_email?: string;
  graduation_year?: number;
  fafsa_status: string;
  aid_received: number;
  notes?: string;
  created_at: string;
}

export const CounselorPortalPage: React.FC = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<CounselorProfile | null>(null);
  const [students, setStudents] = useState<CounselorStudent[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAddingStudent, setIsAddingStudent] = useState(false);
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  // Form states
  const [profileForm, setProfileForm] = useState({
    full_name: '',
    school_name: '',
    school_district: '',
    phone_number: ''
  });

  const [studentForm, setStudentForm] = useState({
    student_name: '',
    student_email: '',
    graduation_year: new Date().getFullYear() + 1,
    fafsa_status: 'not_started',
    aid_received: 0,
    notes: ''
  });

  useEffect(() => {
    if (user) {
      fetchCounselorData();
    }
  }, [user]);

  const fetchCounselorData = async () => {
    try {
      // Fetch counselor profile
      const { data: profileData } = await supabase
        .from('counselor_profiles_2025_10_06_00_42')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (profileData) {
        setProfile(profileData);
        setProfileForm({
          full_name: profileData.full_name || '',
          school_name: profileData.school_name || '',
          school_district: profileData.school_district || '',
          phone_number: profileData.phone_number || ''
        });
      }

      // Fetch counselor's students
      const { data: studentsData } = await supabase
        .from('counselor_students_2025_10_06_00_42')
        .select('*')
        .eq('counselor_id', user?.id)
        .order('created_at', { ascending: false });

      if (studentsData) {
        setStudents(studentsData);
      }
    } catch (error) {
      console.error('Error fetching counselor data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveProfile = async () => {
    try {
      const { error } = await supabase
        .from('counselor_profiles_2025_10_06_00_42')
        .upsert({
          id: user?.id,
          email: user?.email,
          ...profileForm
        });

      if (error) throw error;

      toast({
        title: "Profile Updated",
        description: "Your counselor profile has been saved successfully",
      });

      setIsEditingProfile(false);
      fetchCounselorData();
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: "Error",
        description: "Failed to save profile",
        variant: "destructive",
      });
    }
  };

  const addStudent = async () => {
    if (!studentForm.student_name.trim()) {
      toast({
        title: "Error",
        description: "Student name is required",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('counselor_students_2025_10_06_00_42')
        .insert({
          counselor_id: user?.id,
          ...studentForm
        });

      if (error) throw error;

      toast({
        title: "Student Added",
        description: "Student has been added to your tracking list",
      });

      setStudentForm({
        student_name: '',
        student_email: '',
        graduation_year: new Date().getFullYear() + 1,
        fafsa_status: 'not_started',
        aid_received: 0,
        notes: ''
      });
      setIsAddingStudent(false);
      fetchCounselorData();
    } catch (error) {
      console.error('Error adding student:', error);
      toast({
        title: "Error",
        description: "Failed to add student",
        variant: "destructive",
      });
    }
  };

  const updateStudentStatus = async (studentId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('counselor_students_2025_10_06_00_42')
        .update({ fafsa_status: newStatus })
        .eq('id', studentId);

      if (error) throw error;

      setStudents(students.map(student => 
        student.id === studentId ? { ...student, fafsa_status: newStatus } : student
      ));

      toast({
        title: "Status Updated",
        description: "Student FAFSA status has been updated",
      });
    } catch (error) {
      console.error('Error updating student status:', error);
      toast({
        title: "Error",
        description: "Failed to update student status",
        variant: "destructive",
      });
    }
  };

  const deleteStudent = async (studentId: string) => {
    try {
      const { error } = await supabase
        .from('counselor_students_2025_10_06_00_42')
        .delete()
        .eq('id', studentId);

      if (error) throw error;

      setStudents(students.filter(student => student.id !== studentId));

      toast({
        title: "Student Removed",
        description: "Student has been removed from your tracking list",
      });
    } catch (error) {
      console.error('Error deleting student:', error);
      toast({
        title: "Error",
        description: "Failed to remove student",
        variant: "destructive",
      });
    }
  };

  const exportData = () => {
    const csvContent = [
      ['Student Name', 'Email', 'Graduation Year', 'FAFSA Status', 'Aid Received', 'Notes'],
      ...students.map(student => [
        student.student_name,
        student.student_email || '',
        student.graduation_year || '',
        student.fafsa_status,
        student.aid_received,
        student.notes || ''
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `students_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'in_progress': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'submitted': return <FileText className="h-4 w-4" />;
      case 'in_progress': return <Clock className="h-4 w-4" />;
      default: return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getProgressStats = () => {
    const total = students.length;
    const completed = students.filter(s => s.fafsa_status === 'completed').length;
    const submitted = students.filter(s => s.fafsa_status === 'submitted').length;
    const inProgress = students.filter(s => s.fafsa_status === 'in_progress').length;
    const notStarted = students.filter(s => s.fafsa_status === 'not_started').length;

    return { total, completed, submitted, inProgress, notStarted };
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading counselor portal...</p>
        </div>
      </div>
    );
  }

  const stats = getProgressStats();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Counselor Portal</h1>
            <p className="text-gray-600 mt-2">
              Track and manage your students' FAFSA progress
            </p>
          </div>
          
          <div className="flex space-x-4">
            <Button onClick={exportData} variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            
            <Dialog open={isAddingStudent} onOpenChange={setIsAddingStudent}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Student
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Student</DialogTitle>
                  <DialogDescription>
                    Add a student to track their FAFSA progress
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="student_name">Student Name *</Label>
                    <Input
                      id="student_name"
                      value={studentForm.student_name}
                      onChange={(e) => setStudentForm({...studentForm, student_name: e.target.value})}
                      placeholder="Enter student's full name"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="student_email">Student Email</Label>
                    <Input
                      id="student_email"
                      type="email"
                      value={studentForm.student_email}
                      onChange={(e) => setStudentForm({...studentForm, student_email: e.target.value})}
                      placeholder="student@email.com"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="graduation_year">Graduation Year</Label>
                      <Input
                        id="graduation_year"
                        type="number"
                        value={studentForm.graduation_year}
                        onChange={(e) => setStudentForm({...studentForm, graduation_year: parseInt(e.target.value)})}
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="fafsa_status">FAFSA Status</Label>
                      <Select value={studentForm.fafsa_status} onValueChange={(value) => setStudentForm({...studentForm, fafsa_status: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="not_started">Not Started</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="submitted">Submitted</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={studentForm.notes}
                      onChange={(e) => setStudentForm({...studentForm, notes: e.target.value})}
                      placeholder="Any additional notes about this student..."
                    />
                  </div>
                  
                  <div className="flex justify-end space-x-2">
                    <Button variant="outline" onClick={() => setIsAddingStudent(false)}>
                      Cancel
                    </Button>
                    <Button onClick={addStudent}>
                      Add Student
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="students">Students</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-8">
            {/* Progress Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
                  <p className="text-sm text-gray-600">Total Students</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
                  <p className="text-sm text-gray-600">Completed</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats.submitted}</div>
                  <p className="text-sm text-gray-600">Submitted</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-yellow-600">{stats.inProgress}</div>
                  <p className="text-sm text-gray-600">In Progress</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6 text-center">
                  <div className="text-2xl font-bold text-gray-600">{stats.notStarted}</div>
                  <p className="text-sm text-gray-600">Not Started</p>
                </CardContent>
              </Card>
            </div>

            {/* Progress Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  FAFSA Completion Progress
                </CardTitle>
                <CardDescription>
                  Track your students' progress through the FAFSA process
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Completion Rate</span>
                    <span className="text-sm text-gray-600">
                      {stats.total > 0 ? Math.round(((stats.completed + stats.submitted) / stats.total) * 100) : 0}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-green-600 h-2 rounded-full" 
                      style={{ 
                        width: stats.total > 0 ? `${((stats.completed + stats.submitted) / stats.total) * 100}%` : '0%' 
                      }}
                    ></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="students" className="mt-8">
            {students.length > 0 ? (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2" />
                    Student List ({students.length})
                  </CardTitle>
                  <CardDescription>
                    Manage and track your students' FAFSA progress
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {students.map((student) => (
                      <div key={student.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{student.student_name}</h4>
                          <div className="flex items-center space-x-4 mt-1">
                            {student.student_email && (
                              <span className="text-sm text-gray-600">{student.student_email}</span>
                            )}
                            {student.graduation_year && (
                              <span className="text-sm text-gray-600">Class of {student.graduation_year}</span>
                            )}
                            {student.aid_received > 0 && (
                              <span className="text-sm text-green-600 font-medium">
                                ${student.aid_received.toLocaleString()} aid received
                              </span>
                            )}
                          </div>
                          {student.notes && (
                            <p className="text-sm text-gray-600 mt-2">{student.notes}</p>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <Select 
                            value={student.fafsa_status} 
                            onValueChange={(value) => updateStudentStatus(student.id, value)}
                          >
                            <SelectTrigger className="w-40">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="not_started">Not Started</SelectItem>
                              <SelectItem value="in_progress">In Progress</SelectItem>
                              <SelectItem value="submitted">Submitted</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                            </SelectContent>
                          </Select>
                          
                          <Badge className={getStatusColor(student.fafsa_status)}>
                            {getStatusIcon(student.fafsa_status)}
                            <span className="ml-1">{student.fafsa_status.replace('_', ' ')}</span>
                          </Badge>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteStudent(student.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Students Added</h3>
                  <p className="text-gray-600 mb-6">
                    Start tracking your students' FAFSA progress by adding them to your list
                  </p>
                  <Button onClick={() => setIsAddingStudent(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Your First Student
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="profile" className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Counselor Profile</CardTitle>
                <CardDescription>
                  Manage your counselor profile information
                </CardDescription>
              </CardHeader>
              <CardContent>
                {profile && !isEditingProfile ? (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Full Name</Label>
                        <p className="text-gray-900">{profile.full_name || 'Not provided'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Email</Label>
                        <p className="text-gray-900">{profile.email}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">School Name</Label>
                        <p className="text-gray-900">{profile.school_name || 'Not provided'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">School District</Label>
                        <p className="text-gray-900">{profile.school_district || 'Not provided'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Phone Number</Label>
                        <p className="text-gray-900">{profile.phone_number || 'Not provided'}</p>
                      </div>
                      <div>
                        <Label className="text-sm font-medium text-gray-700">Verification Status</Label>
                        <Badge variant={profile.is_verified ? "default" : "secondary"}>
                          {profile.is_verified ? "Verified" : "Pending Verification"}
                        </Badge>
                      </div>
                    </div>
                    
                    <Button onClick={() => setIsEditingProfile(true)}>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit Profile
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="full_name">Full Name</Label>
                        <Input
                          id="full_name"
                          value={profileForm.full_name}
                          onChange={(e) => setProfileForm({...profileForm, full_name: e.target.value})}
                          placeholder="Your full name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone_number">Phone Number</Label>
                        <Input
                          id="phone_number"
                          value={profileForm.phone_number}
                          onChange={(e) => setProfileForm({...profileForm, phone_number: e.target.value})}
                          placeholder="(555) 123-4567"
                        />
                      </div>
                      <div>
                        <Label htmlFor="school_name">School Name</Label>
                        <Input
                          id="school_name"
                          value={profileForm.school_name}
                          onChange={(e) => setProfileForm({...profileForm, school_name: e.target.value})}
                          placeholder="Your school name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="school_district">School District</Label>
                        <Input
                          id="school_district"
                          value={profileForm.school_district}
                          onChange={(e) => setProfileForm({...profileForm, school_district: e.target.value})}
                          placeholder="Your school district"
                        />
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <Button onClick={saveProfile}>
                        Save Profile
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditingProfile(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};