import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Star, 
  Quote, 
  GraduationCap, 
  DollarSign, 
  MapPin,
  Calendar,
  Award,
  Heart,
  Users,
  TrendingUp,
  BookOpen,
  Play
} from 'lucide-react';

interface SuccessStory {
  id: string;
  name: string;
  photo: string;
  country: string;
  college: string;
  major: string;
  graduationYear: number;
  story: string;
  quote: string;
  aidReceived: number;
  challenges: string[];
  achievements: string[];
  videoUrl?: string;
  featured: boolean;
}

interface CounselorTestimonial {
  id: string;
  name: string;
  title: string;
  school: string;
  photo: string;
  testimonial: string;
  studentsHelped: number;
}

export const SuccessStoriesPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  const successStories: SuccessStory[] = [
    {
      id: '1',
      name: 'Maria Rodriguez',
      photo: '/images/student1.jpg',
      country: 'Mexico',
      college: 'Stanford University',
      major: 'Computer Science',
      graduationYear: 2024,
      story: 'As a first-generation college student from Mexico, I had no idea where to start with US college applications. Global Pathways guided me through every step of the FAFSA process and helped me find scholarships I never knew existed. The multilingual support was crucial - I could switch between English and Spanish whenever I got confused.',
      quote: 'Global Pathways didn\'t just help me get into college - they helped me believe I belonged there.',
      aidReceived: 45000,
      challenges: ['First-generation student', 'Language barrier', 'Complex financial aid process'],
      achievements: ['Full scholarship to Stanford', 'Dean\'s List', 'Software engineering internship at Google'],
      featured: true
    },
    {
      id: '2',
      name: 'Ahmed Hassan',
      photo: '/images/student2.jpg',
      country: 'Egypt',
      college: 'MIT',
      major: 'Electrical Engineering',
      graduationYear: 2023,
      story: 'Coming from Cairo, the US college system seemed impossible to navigate. The FAFSA was particularly confusing for international students. Global Pathways\' step-by-step guide and the counselor portal helped my high school counselor support me better. I received need-based aid that made MIT affordable.',
      quote: 'The scholarship search tool found opportunities I would have never discovered on my own.',
      aidReceived: 52000,
      challenges: ['International student status', 'Complex visa requirements', 'Limited financial resources'],
      achievements: ['MIT full ride', 'Research published in IEEE', 'Founded robotics club'],
      featured: true
    },
    {
      id: '3',
      name: 'Priya Patel',
      photo: '/images/student3.jpg',
      country: 'India',
      college: 'Harvard University',
      major: 'Pre-Med',
      graduationYear: 2025,
      story: 'My family runs a small business in Mumbai, and we thought Harvard was financially impossible. Global Pathways showed us how need-blind admissions work and helped us understand that top universities often provide the best financial aid. The cost calculator helped us plan and budget effectively.',
      quote: 'I learned that the sticker price isn\'t what you actually pay - financial aid makes dreams possible.',
      aidReceived: 65000,
      challenges: ['Middle-class income gap', 'Competitive applicant pool', 'Medical school preparation'],
      achievements: ['Harvard acceptance', 'Pre-med track', 'Hospital volunteer work'],
      featured: false
    },
    {
      id: '4',
      name: 'Jean-Luc Dubois',
      photo: '/images/student4.jpg',
      country: 'France',
      college: 'UC Berkeley',
      major: 'Environmental Science',
      graduationYear: 2024,
      story: 'As an environmental activist from Lyon, I wanted to study sustainability in the US. The scholarship database helped me find environmental scholarships I qualified for. The multilingual support in French made the process much easier for my parents to understand and support.',
      quote: 'Global Pathways connected me with scholarships specifically for environmental studies that covered 80% of my costs.',
      aidReceived: 35000,
      challenges: ['Specialized field requirements', 'Out-of-state tuition', 'Environmental focus'],
      achievements: ['Environmental scholarship recipient', 'Research assistant', 'Climate action leader'],
      featured: false
    },
    {
      id: '5',
      name: 'Sarah Johnson',
      photo: '/images/student5.jpg',
      country: 'United States',
      college: 'Yale University',
      major: 'International Relations',
      graduationYear: 2023,
      story: 'As a first-generation American whose parents immigrated from Nigeria, I felt lost in the college process. My high school counselor used Global Pathways\' counselor portal to track my progress and ensure I didn\'t miss any deadlines. The impact metrics showed me I wasn\'t alone in this journey.',
      quote: 'Seeing other students like me succeed gave me the confidence to apply to my dream schools.',
      aidReceived: 58000,
      challenges: ['First-generation college student', 'Complex family finances', 'High expectations'],
      achievements: ['Yale full scholarship', 'Student government president', 'UN internship'],
      featured: true
    }
  ];

  const counselorTestimonials: CounselorTestimonial[] = [
    {
      id: '1',
      name: 'Ms. Jennifer Chen',
      title: 'College Counselor',
      school: 'Lincoln High School, Los Angeles',
      photo: '/images/counselor1.jpg',
      testimonial: 'Global Pathways has transformed how I support my students. The counselor portal lets me track 200+ students\' FAFSA progress in real-time. The multilingual resources help me serve our diverse student body better. In just one year, our FAFSA completion rate increased from 60% to 95%.',
      studentsHelped: 247
    },
    {
      id: '2',
      name: 'Mr. David Rodriguez',
      title: 'Financial Aid Coordinator',
      school: 'Roosevelt Community College',
      photo: '/images/counselor2.jpg',
      testimonial: 'The scholarship database is incredible. I can filter opportunities by student demographics and academic interests. The automated reminders ensure students don\'t miss deadlines. My students have unlocked over $500,000 in scholarships this year alone.',
      studentsHelped: 156
    },
    {
      id: '3',
      name: 'Dr. Lisa Thompson',
      title: 'Director of College Prep',
      school: 'International Academy',
      photo: '/images/counselor3.jpg',
      testimonial: 'Working with international students requires specialized knowledge. Global Pathways provides accurate, up-to-date information about visa requirements, financial aid for international students, and cultural adaptation resources. It\'s become an essential tool in our office.',
      studentsHelped: 89
    }
  ];

  const impactMetrics = {
    studentsHelped: 2847,
    scholarshipsUnlocked: 2100000,
    fafsaCompletions: 1956,
    collegeAcceptances: 1234,
    averageAidPerStudent: 42000
  };

  const filteredStories = selectedCategory === 'all' 
    ? successStories 
    : selectedCategory === 'featured'
    ? successStories.filter(story => story.featured)
    : successStories.filter(story => story.country.toLowerCase().includes(selectedCategory));

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Success Stories</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Real students sharing their journeys from application to acceptance. 
            See how Global Pathways helped them achieve their college dreams.
          </p>
        </div>

        {/* Impact Metrics */}
        <section className="mb-16">
          <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardContent className="pt-8 pb-8">
              <div className="grid md:grid-cols-5 gap-8 text-center">
                <div>
                  <div className="text-4xl font-bold mb-2">{impactMetrics.studentsHelped.toLocaleString()}+</div>
                  <p className="text-blue-100">Students Helped</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">${(impactMetrics.scholarshipsUnlocked / 1000000).toFixed(1)}M+</div>
                  <p className="text-blue-100">Scholarships Unlocked</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">{impactMetrics.fafsaCompletions.toLocaleString()}+</div>
                  <p className="text-blue-100">FAFSA Completions</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">{impactMetrics.collegeAcceptances.toLocaleString()}+</div>
                  <p className="text-blue-100">College Acceptances</p>
                </div>
                <div>
                  <div className="text-4xl font-bold mb-2">${(impactMetrics.averageAidPerStudent / 1000).toFixed(0)}K</div>
                  <p className="text-blue-100">Avg Aid Per Student</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Filter Buttons */}
        <div className="flex flex-wrap gap-4 justify-center mb-8">
          <Button
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('all')}
          >
            All Stories
          </Button>
          <Button
            variant={selectedCategory === 'featured' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('featured')}
          >
            Featured
          </Button>
          <Button
            variant={selectedCategory === 'mexico' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('mexico')}
          >
            Mexico
          </Button>
          <Button
            variant={selectedCategory === 'india' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('india')}
          >
            India
          </Button>
          <Button
            variant={selectedCategory === 'egypt' ? 'default' : 'outline'}
            onClick={() => setSelectedCategory('egypt')}
          >
            Middle East
          </Button>
        </div>

        {/* Featured Stories */}
        <section className="mb-16">
          <div className="grid lg:grid-cols-2 gap-8">
            {filteredStories.map((story) => (
              <Card key={story.id} className={`hover:shadow-lg transition-shadow ${story.featured ? 'border-2 border-blue-200' : ''}`}>
                {story.featured && (
                  <div className="bg-blue-600 text-white px-4 py-2 text-sm font-medium">
                    ⭐ Featured Story
                  </div>
                )}
                
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                      <GraduationCap className="h-8 w-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl">{story.name}</CardTitle>
                      <CardDescription className="flex items-center mt-1">
                        <MapPin className="h-4 w-4 mr-1" />
                        {story.country} → {story.college}
                      </CardDescription>
                      <div className="flex flex-wrap gap-2 mt-2">
                        <Badge variant="outline">{story.major}</Badge>
                        <Badge variant="outline">Class of {story.graduationYear}</Badge>
                        {story.aidReceived > 0 && (
                          <Badge className="bg-green-100 text-green-800">
                            ${story.aidReceived.toLocaleString()} aid
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  {/* Quote */}
                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <Quote className="h-5 w-5 text-blue-600 mb-2" />
                    <p className="text-blue-900 italic">"{story.quote}"</p>
                  </div>

                  {/* Story */}
                  <p className="text-gray-700 mb-4 leading-relaxed">{story.story}</p>

                  {/* Challenges & Achievements */}
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Challenges Overcome:</h4>
                      <ul className="space-y-1">
                        {story.challenges.map((challenge, index) => (
                          <li key={index} className="text-sm text-gray-600 flex items-start">
                            <div className="w-2 h-2 bg-red-400 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                            {challenge}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Key Achievements:</h4>
                      <ul className="space-y-1">
                        {story.achievements.map((achievement, index) => (
                          <li key={index} className="text-sm text-gray-600 flex items-start">
                            <div className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-2 flex-shrink-0"></div>
                            {achievement}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Video */}
                  {story.videoUrl && (
                    <div className="mt-4">
                      <Button
                        variant="outline"
                        onClick={() => setPlayingVideo(story.id)}
                        className="flex items-center"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Watch {story.name}'s Story
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Counselor Testimonials */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Counselors Say</h2>
            <p className="text-lg text-gray-600">
              High school counselors and college advisors share their experience with Global Pathways
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {counselorTestimonials.map((counselor) => (
              <Card key={counselor.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-600 rounded-full flex items-center justify-center">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{counselor.name}</CardTitle>
                      <CardDescription>{counselor.title}</CardDescription>
                      <p className="text-sm text-gray-500">{counselor.school}</p>
                    </div>
                  </div>
                </CardHeader>

                <CardContent>
                  <div className="bg-gray-50 p-4 rounded-lg mb-4">
                    <Quote className="h-4 w-4 text-gray-600 mb-2" />
                    <p className="text-gray-700 text-sm italic">{counselor.testimonial}</p>
                  </div>

                  <div className="flex items-center justify-between">
                    <Badge className="bg-blue-100 text-blue-800">
                      <Users className="h-3 w-3 mr-1" />
                      {counselor.studentsHelped} students helped
                    </Badge>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center bg-blue-600 text-white rounded-lg p-12">
          <h2 className="text-3xl font-bold mb-4">Ready to Write Your Success Story?</h2>
          <p className="text-xl mb-8 text-blue-100 max-w-2xl mx-auto">
            Join thousands of students who have achieved their college dreams with Global Pathways. 
            Start your journey today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-white text-blue-600 hover:bg-blue-50">
              <BookOpen className="h-4 w-4 mr-2" />
              Start FAFSA Guide
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <TrendingUp className="h-4 w-4 mr-2" />
              Find Scholarships
            </Button>
            <Button variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              <Award className="h-4 w-4 mr-2" />
              Calculate Costs
            </Button>
          </div>
        </section>

        {/* Share Your Story */}
        <section className="mt-16">
          <Card className="bg-green-50 border-green-200">
            <CardContent className="pt-8 pb-8 text-center">
              <Heart className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Share Your Success Story</h3>
              <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
                Have you used Global Pathways to achieve your college goals? We'd love to feature your story 
                and inspire other students on their journey.
              </p>
              <Button className="bg-green-600 hover:bg-green-700">
                Submit Your Story
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
};